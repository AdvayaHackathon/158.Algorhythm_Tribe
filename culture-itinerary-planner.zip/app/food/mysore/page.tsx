import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MapPin, Clock, Phone, ArrowLeft, Star, ExternalLink, Bookmark } from "lucide-react"

const restaurants = [
  {
    id: 1,
    name: "Mylari Dosa Hotel",
    description:
      "A legendary eatery famous for its soft butter dosas that melt in your mouth. This small, unassuming place has been serving its signature dosas for decades.",
    image: "/placeholder.svg?height=400&width=600",
    timings: "6:30 AM - 1:00 PM, 4:00 PM - 8:00 PM",
    contact: "+91 9876543210",
    location: "Shop No. 79, Nazarbad Main Road, Mysore",
    rating: 4.8,
    priceRange: "₹",
    mustTry: ["Mylari Dosa", "Idli", "Filter Coffee"],
    tags: ["Breakfast", "South Indian", "Budget-friendly"],
  },
  {
    id: 2,
    name: "RRR Restaurant",
    description:
      "A popular restaurant serving authentic South Indian thalis and meals. Known for its consistent quality and traditional flavors.",
    image: "/placeholder.svg?height=400&width=600",
    timings: "7:00 AM - 10:30 PM",
    contact: "+91 9876543211",
    location: "Sayyaji Rao Road, Mysore",
    rating: 4.5,
    priceRange: "₹₹",
    mustTry: ["South Indian Thali", "Bisibele Bath", "Ragi Mudde"],
    tags: ["South Indian", "Thali", "Family Dining"],
  },
  {
    id: 3,
    name: "Hotel Ruchi",
    description:
      "A vegetarian restaurant offering traditional Karnataka meals served on banana leaves. Popular among locals for its authentic flavors.",
    image: "/placeholder.svg?height=400&width=600",
    timings: "11:30 AM - 3:30 PM, 7:00 PM - 10:30 PM",
    contact: "+91 9876543212",
    location: "Kalidasa Road, Mysore",
    rating: 4.6,
    priceRange: "₹₹",
    mustTry: ["Karnataka Meals", "Mysore Masala Dosa", "Khara Bath"],
    tags: ["Traditional", "Vegetarian", "Local Cuisine"],
  },
  {
    id: 4,
    name: "Depth N Green",
    description:
      "A modern vegetarian restaurant with a focus on healthy and organic ingredients. Offers a mix of traditional and contemporary dishes.",
    image: "/placeholder.svg?height=400&width=600",
    timings: "11:00 AM - 10:00 PM",
    contact: "+91 9876543213",
    location: "Karanji Lake Road, Mysore",
    rating: 4.4,
    priceRange: "₹₹₹",
    mustTry: ["Organic Thali", "Ragi Dosa", "Fruit Salad"],
    tags: ["Vegetarian", "Healthy", "Organic"],
  },
]

const dishes = [
  {
    id: 1,
    name: "Mysore Masala Dosa",
    description: "A crispy crepe with spicy red chutney inside and potato filling, originating from Mysore.",
    image: "/placeholder.svg?height=300&width=400",
    bestPlace: "Mylari Dosa Hotel",
    price: "₹40-60",
    category: "Breakfast",
  },
  {
    id: 2,
    name: "Mysore Pak",
    description:
      "A traditional sweet made from gram flour, ghee, and sugar, invented in the kitchens of Mysore Palace.",
    image: "/placeholder.svg?height=300&width=400",
    bestPlace: "Guru Sweets",
    price: "₹350-400 per kg",
    category: "Dessert",
  },
  {
    id: 3,
    name: "Bisi Bele Bath",
    description: "A spicy rice dish made with lentils, vegetables, and aromatic spices, served hot.",
    image: "/placeholder.svg?height=300&width=400",
    bestPlace: "RRR Restaurant",
    price: "₹80-100",
    category: "Main Course",
  },
  {
    id: 4,
    name: "Ragi Mudde",
    description: "A traditional ball made from finger millet flour, typically served with Bassaru (lentil curry).",
    image: "/placeholder.svg?height=300&width=400",
    bestPlace: "Hotel Ruchi",
    price: "₹70-90",
    category: "Main Course",
  },
  {
    id: 5,
    name: "Filter Coffee",
    description: "A strong coffee made with chicory, served in a traditional brass tumbler and davara (saucer).",
    image: "/placeholder.svg?height=300&width=400",
    bestPlace: "Mylari Dosa Hotel",
    price: "₹20-30",
    category: "Beverage",
  },
  {
    id: 6,
    name: "Chiroti",
    description: "A flaky, layered sweet pastry dusted with powdered sugar and sometimes served with Badam milk.",
    image: "/placeholder.svg?height=300&width=400",
    bestPlace: "Guru Sweets",
    price: "₹20-30 per piece",
    category: "Dessert",
  },
]

export default function MysoreFoodPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Link
          href="/food"
          className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-foreground mb-4"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Food
        </Link>
        <h1 className="text-4xl font-bold tracking-tight mb-4">Mysore Cuisine</h1>
        <p className="text-lg text-muted-foreground max-w-3xl">
          Discover the royal flavors of Mysore, from traditional South Indian breakfast to sweet delicacies and
          authentic Karnataka meals.
        </p>
      </div>

      <Tabs defaultValue="restaurants" className="w-full mb-16">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="restaurants">Restaurants</TabsTrigger>
          <TabsTrigger value="dishes">Must-Try Dishes</TabsTrigger>
          <TabsTrigger value="specialties">Local Specialties</TabsTrigger>
        </TabsList>
        <TabsContent value="restaurants" className="p-4">
          <div className="grid grid-cols-1 gap-8">
            {restaurants.map((restaurant) => (
              <Card key={restaurant.id} className="overflow-hidden">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="md:col-span-1">
                    <img
                      src={restaurant.image || "/placeholder.svg"}
                      alt={restaurant.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="md:col-span-2 p-6">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="text-xl font-bold">{restaurant.name}</h3>
                        <div className="flex items-center mt-1 mb-2">
                          <div className="flex items-center">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`h-4 w-4 ${i < Math.floor(restaurant.rating) ? "text-amber-500 fill-amber-500" : "text-gray-300"}`}
                              />
                            ))}
                          </div>
                          <span className="ml-2 text-sm font-medium">{restaurant.rating}</span>
                          <span className="mx-2 text-muted-foreground">•</span>
                          <span className="text-sm text-muted-foreground">{restaurant.priceRange}</span>
                        </div>
                      </div>
                      <Button variant="ghost" size="icon">
                        <Bookmark className="h-5 w-5" />
                        <span className="sr-only">Bookmark</span>
                      </Button>
                    </div>
                    <p className="text-muted-foreground mb-4">{restaurant.description}</p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div className="flex items-start gap-2">
                        <Clock className="h-5 w-5 text-amber-500 mt-0.5" />
                        <div>
                          <p className="font-medium">Timings</p>
                          <p className="text-sm text-muted-foreground">{restaurant.timings}</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-2">
                        <Phone className="h-5 w-5 text-amber-500 mt-0.5" />
                        <div>
                          <p className="font-medium">Contact</p>
                          <p className="text-sm text-muted-foreground">{restaurant.contact}</p>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-start gap-2 mb-4">
                      <MapPin className="h-5 w-5 text-amber-500 mt-0.5" />
                      <div>
                        <p className="font-medium">Location</p>
                        <p className="text-sm text-muted-foreground">{restaurant.location}</p>
                      </div>
                    </div>
                    <div className="mb-4">
                      <p className="font-medium mb-1">Must Try</p>
                      <div className="flex flex-wrap gap-2">
                        {restaurant.mustTry.map((item, index) => (
                          <span
                            key={index}
                            className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100 text-xs px-2 py-1 rounded-full"
                          >
                            {item}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {restaurant.tags.map((tag, index) => (
                        <span
                          key={index}
                          className="bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-100 text-xs px-2 py-1 rounded-full"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="dishes" className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {dishes.map((dish) => (
              <Card key={dish.id} className="overflow-hidden">
                <div className="h-48 overflow-hidden">
                  <img src={dish.image || "/placeholder.svg"} alt={dish.name} className="w-full h-full object-cover" />
                </div>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <CardTitle>{dish.name}</CardTitle>
                    <span className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100 text-xs px-2 py-1 rounded-full">
                      {dish.category}
                    </span>
                  </div>
                  <CardDescription>{dish.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm font-medium">Best Place to Try</p>
                      <p className="text-sm text-muted-foreground">{dish.bestPlace}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Price Range</p>
                      <p className="text-sm text-muted-foreground">{dish.price}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="specialties" className="p-4">
          <Card>
            <CardHeader>
              <CardTitle>Mysore Culinary Specialties</CardTitle>
              <CardDescription>
                Unique food traditions and specialties that define Mysore's culinary identity
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-2">Royal Influence</h3>
                <p className="text-muted-foreground">
                  Mysore's cuisine has been heavily influenced by the royal kitchens of the Wadiyar dynasty. Many dishes
                  feature rich, aromatic spices and ghee, reflecting the royal heritage. The famous Mysore Pak was
                  created in the royal kitchen for King Krishna Raja Wadiyar IV.
                </p>
              </div>
              <div>
                <h3 className="text-lg font-medium mb-2">Traditional Breakfast Culture</h3>
                <p className="text-muted-foreground">
                  Mysore has a strong breakfast tradition with iconic dishes like Mysore Masala Dosa, Idli, Vada, and
                  Khara Bath (upma). Many locals and tourists start their day at the city's famous breakfast joints that
                  have been operating for generations.
                </p>
              </div>
              <div>
                <h3 className="text-lg font-medium mb-2">Coffee Connection</h3>
                <p className="text-muted-foreground">
                  Filter coffee is an integral part of Mysore's food culture. The traditional South Indian filter coffee
                  is made with a blend of coffee and chicory, served in a brass tumbler and davara (saucer). The coffee
                  is often poured from a height to create a frothy top.
                </p>
              </div>
              <div>
                <h3 className="text-lg font-medium mb-2">Sweet Traditions</h3>
                <p className="text-muted-foreground">
                  Besides Mysore Pak, the city is known for sweets like Chiroti, Obbattu (holige), and Mysore Rasagolla.
                  These sweets are especially popular during festivals and celebrations.
                </p>
              </div>
              <div>
                <h3 className="text-lg font-medium mb-2">Culinary Festivals</h3>
                <p className="text-muted-foreground">
                  During the Dasara festival, Mysore's culinary scene comes alive with special food stalls and events.
                  Many restaurants offer special Dasara thalis featuring a variety of traditional dishes.
                </p>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                <ExternalLink className="mr-2 h-4 w-4" />
                Learn More About Mysore Cuisine
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
