import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MapPin, Clock, Phone, ArrowLeft, Star, ExternalLink, Bookmark } from "lucide-react"

const restaurants = [
  {
    id: 1,
    name: "Mango Tree Restaurant",
    description:
      "A popular riverside restaurant offering a peaceful dining experience with views of paddy fields and the Tungabhadra River. Known for its relaxed atmosphere and diverse menu.",
    image: "/placeholder.svg?height=400&width=600",
    timings: "8:00 AM - 10:00 PM",
    contact: "+91 9876543214",
    location: "Hampi Bazaar, near Virupaksha Temple, Hampi",
    rating: 4.7,
    priceRange: "₹₹",
    mustTry: ["Banana Pancakes", "Thali", "Fresh Juices"],
    tags: ["Riverside", "Multi-cuisine", "Vegetarian-friendly"],
  },
  {
    id: 2,
    name: "Gopi Guest House Restaurant",
    description:
      "A rooftop restaurant offering panoramic views of Hampi's boulder-strewn landscape. Serves a mix of Indian and international cuisine.",
    image: "/placeholder.svg?height=400&width=600",
    timings: "7:30 AM - 10:30 PM",
    contact: "+91 9876543215",
    location: "Hampi Bazaar, Hampi",
    rating: 4.5,
    priceRange: "₹₹",
    mustTry: ["North Karnataka Thali", "Israeli Breakfast", "Fruit Lassi"],
    tags: ["Rooftop", "Multi-cuisine", "Views"],
  },
  {
    id: 3,
    name: "The Laughing Buddha Café",
    description:
      "A laid-back café with a bohemian vibe, popular among travelers. Offers a mix of Indian, Israeli, and Western dishes in a relaxed setting.",
    image: "/placeholder.svg?height=400&width=600",
    timings: "8:00 AM - 10:00 PM",
    contact: "+91 9876543216",
    location: "Virupapur Gaddi (Hippie Island), Hampi",
    rating: 4.6,
    priceRange: "₹₹",
    mustTry: ["Hummus Plate", "Shakshuka", "Masala Chai"],
    tags: ["Café", "International", "Relaxed"],
  },
]

const dishes = [
  {
    id: 1,
    name: "Jolada Rotti with Brinjal Curry",
    description:
      "A traditional North Karnataka meal featuring sorghum flatbread served with spicy brinjal (eggplant) curry.",
    image: "/placeholder.svg?height=300&width=400",
    bestPlace: "Gopi Guest House Restaurant",
    price: "₹120-150",
    category: "Main Course",
  },
  {
    id: 2,
    name: "Banana Pancakes",
    description:
      "A traveler's favorite, these sweet pancakes made with ripe bananas are a popular breakfast option in Hampi's cafes.",
    image: "/placeholder.svg?height=300&width=400",
    bestPlace: "Mango Tree Restaurant",
    price: "₹80-100",
    category: "Breakfast",
  },
  {
    id: 3,
    name: "Akki Rotti",
    description:
      "A flatbread made from rice flour, often mixed with vegetables and spices, typical of Karnataka cuisine.",
    image: "/placeholder.svg?height=300&width=400",
    bestPlace: "Gopi Guest House Restaurant",
    price: "₹60-80",
    category: "Breakfast",
  },
  {
    id: 4,
    name: "Fresh Fruit Lassi",
    description: "A refreshing yogurt-based drink blended with seasonal fruits, perfect for Hampi's warm climate.",
    image: "/placeholder.svg?height=300&width=400",
    bestPlace: "The Laughing Buddha Café",
    price: "₹70-90",
    category: "Beverage",
  },
  {
    id: 5,
    name: "Thali",
    description:
      "A complete meal served on a platter with a variety of dishes, including rice, bread, curries, and dessert.",
    image: "/placeholder.svg?height=300&width=400",
    bestPlace: "Mango Tree Restaurant",
    price: "₹150-200",
    category: "Main Course",
  },
  {
    id: 6,
    name: "Coconut Curry",
    description:
      "A flavorful curry made with fresh coconut milk, vegetables, and aromatic spices, popular in riverside restaurants.",
    image: "/placeholder.svg?height=300&width=400",
    bestPlace: "The Laughing Buddha Café",
    price: "₹120-150",
    category: "Main Course",
  },
]

export default function HampiFoodPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Link
          href="/food"
          className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-foreground mb-4"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Food
        </Link>
        <h1 className="text-4xl font-bold tracking-tight mb-4">Hampi Cuisine</h1>
        <p className="text-lg text-muted-foreground max-w-3xl">
          Discover the diverse culinary scene of Hampi, from traditional North Karnataka dishes to international cuisine
          catering to travelers.
        </p>
      </div>

      <Tabs defaultValue="restaurants" className="w-full mb-16">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="restaurants">Restaurants</TabsTrigger>
          <TabsTrigger value="dishes">Must-Try Dishes</TabsTrigger>
          <TabsTrigger value="specialties">Local Specialties</TabsTrigger>
        </TabsList>
        <TabsContent value="restaurants" className="p-4">
          <div className="grid grid-cols-1 gap-8">
            {restaurants.map((restaurant) => (
              <Card key={restaurant.id} className="overflow-hidden">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="md:col-span-1">
                    <img
                      src={restaurant.image || "/placeholder.svg"}
                      alt={restaurant.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="md:col-span-2 p-6">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="text-xl font-bold">{restaurant.name}</h3>
                        <div className="flex items-center mt-1 mb-2">
                          <div className="flex items-center">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`h-4 w-4 ${i < Math.floor(restaurant.rating) ? "text-amber-500 fill-amber-500" : "text-gray-300"}`}
                              />
                            ))}
                          </div>
                          <span className="ml-2 text-sm font-medium">{restaurant.rating}</span>
                          <span className="mx-2 text-muted-foreground">•</span>
                          <span className="text-sm text-muted-foreground">{restaurant.priceRange}</span>
                        </div>
                      </div>
                      <Button variant="ghost" size="icon">
                        <Bookmark className="h-5 w-5" />
                        <span className="sr-only">Bookmark</span>
                      </Button>
                    </div>
                    <p className="text-muted-foreground mb-4">{restaurant.description}</p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div className="flex items-start gap-2">
                        <Clock className="h-5 w-5 text-amber-500 mt-0.5" />
                        <div>
                          <p className="font-medium">Timings</p>
                          <p className="text-sm text-muted-foreground">{restaurant.timings}</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-2">
                        <Phone className="h-5 w-5 text-amber-500 mt-0.5" />
                        <div>
                          <p className="font-medium">Contact</p>
                          <p className="text-sm text-muted-foreground">{restaurant.contact}</p>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-start gap-2 mb-4">
                      <MapPin className="h-5 w-5 text-amber-500 mt-0.5" />
                      <div>
                        <p className="font-medium">Location</p>
                        <p className="text-sm text-muted-foreground">{restaurant.location}</p>
                      </div>
                    </div>
                    <div className="mb-4">
                      <p className="font-medium mb-1">Must Try</p>
                      <div className="flex flex-wrap gap-2">
                        {restaurant.mustTry.map((item, index) => (
                          <span
                            key={index}
                            className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100 text-xs px-2 py-1 rounded-full"
                          >
                            {item}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {restaurant.tags.map((tag, index) => (
                        <span
                          key={index}
                          className="bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-100 text-xs px-2 py-1 rounded-full"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="dishes" className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {dishes.map((dish) => (
              <Card key={dish.id} className="overflow-hidden">
                <div className="h-48 overflow-hidden">
                  <img src={dish.image || "/placeholder.svg"} alt={dish.name} className="w-full h-full object-cover" />
                </div>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <CardTitle>{dish.name}</CardTitle>
                    <span className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100 text-xs px-2 py-1 rounded-full">
                      {dish.category}
                    </span>
                  </div>
                  <CardDescription>{dish.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm font-medium">Best Place to Try</p>
                      <p className="text-sm text-muted-foreground">{dish.bestPlace}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Price Range</p>
                      <p className="text-sm text-muted-foreground">{dish.price}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="specialties" className="p-4">
          <Card>
            <CardHeader>
              <CardTitle>Hampi Culinary Specialties</CardTitle>
              <CardDescription>
                Unique food traditions and specialties that define Hampi's culinary identity
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-2">North Karnataka Influence</h3>
                <p className="text-muted-foreground">
                  Hampi's local cuisine is heavily influenced by North Karnataka food traditions, which feature jowar
                  (sorghum), ragi (finger millet), and spicy curries. Traditional dishes like Jolada Rotti (sorghum
                  flatbread) and Badanekai Yennegai (stuffed brinjal) are staples of the region.
                </p>
              </div>
              <div>
                <h3 className="text-lg font-medium mb-2">Fusion of Cultures</h3>
                <p className="text-muted-foreground">
                  Due to its popularity among international travelers, Hampi has developed a unique food culture that
                  blends traditional Karnataka cuisine with international flavors. Many restaurants offer Israeli,
                  Italian, and other global cuisines alongside local dishes.
                </p>
              </div>
              <div>
                <h3 className="text-lg font-medium mb-2">Riverside Dining</h3>
                <p className="text-muted-foreground">
                  One of Hampi's unique culinary experiences is dining by the Tungabhadra River. Several restaurants
                  offer seating arrangements with views of the river and ancient ruins, creating a magical atmosphere,
                  especially during sunset.
                </p>
              </div>
              <div>
                <h3 className="text-lg font-medium mb-2">Fresh and Local Ingredients</h3>
                <p className="text-muted-foreground">
                  Many restaurants in Hampi pride themselves on using fresh, locally sourced ingredients. Bananas,
                  coconuts, and seasonal vegetables from nearby farms feature prominently in the local cuisine.
                </p>
              </div>
              <div>
                <h3 className="text-lg font-medium mb-2">Traveler's Comfort Food</h3>
                <p className="text-muted-foreground">
                  Dishes like banana pancakes, fruit lassis, and fresh juices have become synonymous with Hampi's food
                  scene, catering to travelers looking for familiar comfort food during their explorations.
                </p>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                <ExternalLink className="mr-2 h-4 w-4" />
                Learn More About Hampi Cuisine
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
