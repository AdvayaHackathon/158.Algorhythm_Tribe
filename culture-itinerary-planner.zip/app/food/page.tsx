import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Utensils, Star, ArrowRight } from "lucide-react"

export default function FoodPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col items-center text-center mb-12">
        <h1 className="text-4xl font-bold tracking-tight mb-4">Culinary Delights</h1>
        <p className="text-lg text-muted-foreground max-w-2xl">
          Discover the authentic flavors and culinary traditions of Mysore and Hampi, from royal delicacies to local
          street food.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
        <Card className="overflow-hidden">
          <div className="h-64 overflow-hidden">
            <img
              src="/placeholder.svg?height=400&width=600"
              alt="Traditional Mysore cuisine"
              className="w-full h-full object-cover transition-transform hover:scale-105 duration-500"
            />
          </div>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Utensils className="h-5 w-5 text-amber-500" />
              Mysore Cuisine
            </CardTitle>
            <CardDescription>Experience the royal flavors of Karnataka with traditional Mysore dishes</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="mb-4">
              Mysore's cuisine is influenced by the royal kitchens of the Wadiyar dynasty, featuring aromatic spices,
              coconut, and jaggery. Don't miss the famous Mysore Masala Dosa, Mysore Pak, and filter coffee.
            </p>
            <div className="flex flex-wrap gap-2 mb-4">
              <span className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100 text-xs px-2 py-1 rounded-full">
                Mysore Masala Dosa
              </span>
              <span className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100 text-xs px-2 py-1 rounded-full">
                Mysore Pak
              </span>
              <span className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100 text-xs px-2 py-1 rounded-full">
                Bisi Bele Bath
              </span>
              <span className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100 text-xs px-2 py-1 rounded-full">
                Filter Coffee
              </span>
            </div>
          </CardContent>
          <CardFooter>
            <Link href="/food/mysore" className="w-full">
              <Button className="w-full">
                Explore Mysore Food <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </CardFooter>
        </Card>

        <Card className="overflow-hidden">
          <div className="h-64 overflow-hidden">
            <img
              src="/placeholder.svg?height=400&width=600"
              alt="Hampi local food"
              className="w-full h-full object-cover transition-transform hover:scale-105 duration-500"
            />
          </div>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Utensils className="h-5 w-5 text-amber-500" />
              Hampi Cuisine
            </CardTitle>
            <CardDescription>
              Taste the local flavors of North Karnataka with traditional and fusion dishes
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="mb-4">
              Hampi offers a mix of traditional North Karnataka cuisine and international dishes catering to travelers.
              Try the local Jolada Rotti (sorghum bread), Badanekai Yennegai (stuffed brinjal), and fresh riverside
              meals.
            </p>
            <div className="flex flex-wrap gap-2 mb-4">
              <span className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100 text-xs px-2 py-1 rounded-full">
                Jolada Rotti
              </span>
              <span className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100 text-xs px-2 py-1 rounded-full">
                Badanekai Yennegai
              </span>
              <span className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100 text-xs px-2 py-1 rounded-full">
                Akki Rotti
              </span>
              <span className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100 text-xs px-2 py-1 rounded-full">
                Banana Pancakes
              </span>
            </div>
          </CardContent>
          <CardFooter>
            <Link href="/food/hampi" className="w-full">
              <Button className="w-full">
                Explore Hampi Food <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </CardFooter>
        </Card>
      </div>

      <div className="mb-16">
        <h2 className="text-2xl font-bold mb-6">Popular Dishes to Try</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <div className="h-48 overflow-hidden">
              <img
                src="/placeholder.svg?height=300&width=400"
                alt="Mysore Masala Dosa"
                className="w-full h-full object-cover"
              />
            </div>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Mysore Masala Dosa</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                A crispy crepe with spicy red chutney inside and potato filling, originating from Mysore.
              </p>
            </CardContent>
          </Card>
          <Card>
            <div className="h-48 overflow-hidden">
              <img
                src="/placeholder.svg?height=300&width=400"
                alt="Mysore Pak"
                className="w-full h-full object-cover"
              />
            </div>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Mysore Pak</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                A traditional sweet made from gram flour, ghee, and sugar, invented in the kitchens of Mysore Palace.
              </p>
            </CardContent>
          </Card>
          <Card>
            <div className="h-48 overflow-hidden">
              <img
                src="/placeholder.svg?height=300&width=400"
                alt="Jolada Rotti"
                className="w-full h-full object-cover"
              />
            </div>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Jolada Rotti</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                A flatbread made from sorghum flour, typically served with spicy brinjal curry in North Karnataka.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      <div>
        <h2 className="text-2xl font-bold mb-6">Dining Experiences</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle>Royal Dining in Mysore</CardTitle>
              <CardDescription>Experience the royal flavors of the Wadiyar dynasty</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                Several restaurants in Mysore offer traditional thalis inspired by royal recipes, served on silver
                platters with attentive service. These meals typically include multiple courses with rich gravies,
                aromatic rice dishes, and traditional sweets.
              </p>
              <div className="flex items-center gap-1 text-amber-500">
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
                <span className="ml-2 text-sm text-muted-foreground">Premium Experience</span>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Riverside Dining in Hampi</CardTitle>
              <CardDescription>Enjoy meals with a view of the Tungabhadra River</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                Several cafes and restaurants in Hampi offer dining experiences by the Tungabhadra River, where you can
                enjoy your meal while watching the sunset over ancient ruins. These places typically serve a mix of
                local and international cuisine.
              </p>
              <div className="flex items-center gap-1 text-amber-500">
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4 fill-current" />
                <Star className="h-4 w-4" />
                <span className="ml-2 text-sm text-muted-foreground">Scenic Experience</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
