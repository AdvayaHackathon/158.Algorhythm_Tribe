import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Bus, Train, Car, Bike, MapPin, Clock, ArrowRight, AlertTriangle } from "lucide-react"

export default function TravelPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col items-center text-center mb-12">
        <h1 className="text-4xl font-bold tracking-tight mb-4">Travel Information</h1>
        <p className="text-lg text-muted-foreground max-w-2xl">
          Comprehensive transportation details to help you plan your journey to and around Mysore and Hampi.
        </p>
      </div>

      <Tabs defaultValue="within-cities" className="w-full mb-16">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="within-cities">Within Cities</TabsTrigger>
          <TabsTrigger value="between-cities">Between Cities</TabsTrigger>
          <TabsTrigger value="from-major-cities">From Major Cities</TabsTrigger>
        </TabsList>
        <TabsContent value="within-cities" className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-amber-500" />
                  Getting Around Mysore
                </CardTitle>
                <CardDescription>Transportation options within Mysore city</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="bg-amber-100 dark:bg-amber-900 p-2 rounded-full">
                    <Bus className="h-5 w-5 text-amber-800 dark:text-amber-100" />
                  </div>
                  <div>
                    <h3 className="font-medium">City Buses</h3>
                    <p className="text-sm text-muted-foreground">
                      Mysore has an extensive city bus network operated by KSRTC. Buses are frequent, affordable, and
                      connect all major attractions.
                    </p>
                    <p className="text-sm mt-1">
                      <span className="font-medium">Cost:</span> ₹10-30 depending on distance
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-amber-100 dark:bg-amber-900 p-2 rounded-full">
                    <Car className="h-5 w-5 text-amber-800 dark:text-amber-100" />
                  </div>
                  <div>
                    <h3 className="font-medium">Auto-rickshaws</h3>
                    <p className="text-sm text-muted-foreground">
                      Auto-rickshaws are readily available throughout the city. Always insist on using the meter or
                      negotiate the fare before starting your journey.
                    </p>
                    <p className="text-sm mt-1">
                      <span className="font-medium">Cost:</span> ₹30 minimum, then ₹15-20 per km
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-amber-100 dark:bg-amber-900 p-2 rounded-full">
                    <Bike className="h-5 w-5 text-amber-800 dark:text-amber-100" />
                  </div>
                  <div>
                    <h3 className="font-medium">Bicycles and Two-wheelers</h3>
                    <p className="text-sm text-muted-foreground">
                      Rent bicycles or scooters to explore the city at your own pace. Several rental shops are available
                      near tourist areas.
                    </p>
                    <p className="text-sm mt-1">
                      <span className="font-medium">Cost:</span> Bicycles: ₹100-150 per day, Scooters: ₹300-500 per day
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-amber-100 dark:bg-amber-900 p-2 rounded-full">
                    <Car className="h-5 w-5 text-amber-800 dark:text-amber-100" />
                  </div>
                  <div>
                    <h3 className="font-medium">Taxis and Cab Services</h3>
                    <p className="text-sm text-muted-foreground">
                      App-based cab services like Ola and Uber operate in Mysore. Traditional taxis are also available
                      for hire.
                    </p>
                    <p className="text-sm mt-1">
                      <span className="font-medium">Cost:</span> Starting from ₹150 for short trips
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-amber-500" />
                  Getting Around Hampi
                </CardTitle>
                <CardDescription>Transportation options within Hampi and surrounding areas</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="bg-amber-100 dark:bg-amber-900 p-2 rounded-full">
                    <Bike className="h-5 w-5 text-amber-800 dark:text-amber-100" />
                  </div>
                  <div>
                    <h3 className="font-medium">Bicycles</h3>
                    <p className="text-sm text-muted-foreground">
                      The most popular way to explore Hampi. Bicycles can be rented from shops near Hampi Bazaar and
                      Hippie Island.
                    </p>
                    <p className="text-sm mt-1">
                      <span className="font-medium">Cost:</span> ₹100-150 per day
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-amber-100 dark:bg-amber-900 p-2 rounded-full">
                    <Car className="h-5 w-5 text-amber-800 dark:text-amber-100" />
                  </div>
                  <div>
                    <h3 className="font-medium">Auto-rickshaws</h3>
                    <p className="text-sm text-muted-foreground">
                      Auto-rickshaws are available for shorter distances. They can also be hired for a full day to visit
                      multiple sites.
                    </p>
                    <p className="text-sm mt-1">
                      <span className="font-medium">Cost:</span> ₹300-500 for short trips, ₹1000-1500 for full day
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-amber-100 dark:bg-amber-900 p-2 rounded-full">
                    <Bike className="h-5 w-5 text-amber-800 dark:text-amber-100" />
                  </div>
                  <div>
                    <h3 className="font-medium">Mopeds and Scooters</h3>
                    <p className="text-sm text-muted-foreground">
                      For covering larger distances, mopeds and scooters are convenient options. Available for rent in
                      Hampi Bazaar and Hippie Island.
                    </p>
                    <p className="text-sm mt-1">
                      <span className="font-medium">Cost:</span> ₹300-400 per day
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-amber-100 dark:bg-amber-900 p-2 rounded-full">
                    <Bus className="h-5 w-5 text-amber-800 dark:text-amber-100" />
                  </div>
                  <div>
                    <h3 className="font-medium">Coracle Boats</h3>
                    <p className="text-sm text-muted-foreground">
                      Traditional round boats used to cross the Tungabhadra River between Hampi Bazaar and Hippie
                      Island. A unique experience!
                    </p>
                    <p className="text-sm mt-1">
                      <span className="font-medium">Cost:</span> ₹100 per person for crossing, ₹500-700 for a river tour
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        <TabsContent value="between-cities" className="p-4">
          <Card>
            <CardHeader>
              <CardTitle>Traveling Between Mysore and Hampi</CardTitle>
              <CardDescription>Options for traveling between these two heritage cities</CardDescription>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="train">
                  <AccordionTrigger>
                    <div className="flex items-center gap-2">
                      <Train className="h-5 w-5 text-amber-500" />
                      <span>By Train</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-4">
                      <p className="text-sm text-muted-foreground">
                        There is no direct train between Mysore and Hampi. You need to take a train from Mysore to
                        Hospet (the nearest railway station to Hampi), and then take a local bus or auto-rickshaw to
                        Hampi.
                      </p>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <p className="text-sm font-medium">Duration</p>
                          <p className="text-sm text-muted-foreground">8-10 hours</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium">Cost</p>
                          <p className="text-sm text-muted-foreground">₹400-800 (depending on class)</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium">Frequency</p>
                          <p className="text-sm text-muted-foreground">Limited trains, advance booking recommended</p>
                        </div>
                      </div>
                      <div className="bg-amber-50 dark:bg-amber-950 p-3 rounded-md">
                        <p className="text-sm flex items-start gap-2">
                          <AlertTriangle className="h-4 w-4 text-amber-500 mt-0.5 flex-shrink-0" />
                          <span>
                            You may need to change trains at Bangalore or other junction stations. Check the IRCTC
                            website for the most up-to-date schedules.
                          </span>
                        </p>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="bus">
                  <AccordionTrigger>
                    <div className="flex items-center gap-2">
                      <Bus className="h-5 w-5 text-amber-500" />
                      <span>By Bus</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-4">
                      <p className="text-sm text-muted-foreground">
                        Buses are the most common way to travel between Mysore and Hampi. You can take a bus from Mysore
                        to Hospet, and then a local bus or auto-rickshaw to Hampi.
                      </p>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <p className="text-sm font-medium">Duration</p>
                          <p className="text-sm text-muted-foreground">7-8 hours</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium">Cost</p>
                          <p className="text-sm text-muted-foreground">₹500-1000 (depending on bus type)</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium">Frequency</p>
                          <p className="text-sm text-muted-foreground">Multiple buses daily</p>
                        </div>
                      </div>
                      <div className="bg-amber-50 dark:bg-amber-950 p-3 rounded-md">
                        <p className="text-sm flex items-start gap-2">
                          <AlertTriangle className="h-4 w-4 text-amber-500 mt-0.5 flex-shrink-0" />
                          <span>
                            Overnight buses are available and can save you accommodation costs. KSRTC (Karnataka State
                            Road Transport Corporation) operates regular services, and there are also private operators.
                          </span>
                        </p>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="taxi">
                  <AccordionTrigger>
                    <div className="flex items-center gap-2">
                      <Car className="h-5 w-5 text-amber-500" />
                      <span>By Taxi</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-4">
                      <p className="text-sm text-muted-foreground">
                        Hiring a private taxi is the most comfortable but expensive option. It gives you the flexibility
                        to stop at interesting places along the way.
                      </p>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <p className="text-sm font-medium">Duration</p>
                          <p className="text-sm text-muted-foreground">6-7 hours</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium">Cost</p>
                          <p className="text-sm text-muted-foreground">₹4000-6000 (one way)</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium">Availability</p>
                          <p className="text-sm text-muted-foreground">Available on demand</p>
                        </div>
                      </div>
                      <div className="bg-amber-50 dark:bg-amber-950 p-3 rounded-md">
                        <p className="text-sm flex items-start gap-2">
                          <AlertTriangle className="h-4 w-4 text-amber-500 mt-0.5 flex-shrink-0" />
                          <span>
                            Book through your hotel or a reputable travel agency. Confirm the fare before starting the
                            journey and ensure the driver is familiar with the route.
                          </span>
                        </p>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="self-drive">
                  <AccordionTrigger>
                    <div className="flex items-center gap-2">
                      <Car className="h-5 w-5 text-amber-500" />
                      <span>Self-Drive</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-4">
                      <p className="text-sm text-muted-foreground">
                        If you're comfortable driving in India, renting a car gives you maximum flexibility. The route
                        passes through some scenic areas of Karnataka.
                      </p>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <p className="text-sm font-medium">Duration</p>
                          <p className="text-sm text-muted-foreground">6-7 hours</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium">Cost</p>
                          <p className="text-sm text-muted-foreground">₹2500-4000 (car rental) + fuel</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium">Route</p>
                          <p className="text-sm text-muted-foreground">
                            Mysore → Bangalore → Chitradurga → Hospet → Hampi
                          </p>
                        </div>
                      </div>
                      <div className="bg-amber-50 dark:bg-amber-950 p-3 rounded-md">
                        <p className="text-sm flex items-start gap-2">
                          <AlertTriangle className="h-4 w-4 text-amber-500 mt-0.5 flex-shrink-0" />
                          <span>
                            Roads are generally good, but be prepared for occasional rough patches. Use GPS navigation
                            and download offline maps before starting your journey.
                          </span>
                        </p>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
            <CardFooter>
              <div className="w-full">
                <p className="text-sm text-muted-foreground mb-4">
                  The distance between Mysore and Hampi is approximately 380 kilometers. Plan your journey according to
                  your comfort, budget, and time constraints.
                </p>
                <Button variant="outline" className="w-full">
                  <Clock className="mr-2 h-4 w-4" />
                  Check Latest Schedules
                </Button>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>
        <TabsContent value="from-major-cities" className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>Reaching Mysore</CardTitle>
                <CardDescription>How to reach Mysore from major cities in India</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="font-medium flex items-center gap-2 mb-2">
                    <MapPin className="h-4 w-4 text-amber-500" />
                    From Bangalore
                  </h3>
                  <div className="grid grid-cols-1 gap-3">
                    <div className="flex items-start gap-2">
                      <Train className="h-4 w-4 text-amber-500 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">By Train</p>
                        <p className="text-sm text-muted-foreground">
                          2-3 hours, ₹120-300, frequent trains throughout the day
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <Bus className="h-4 w-4 text-amber-500 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">By Bus</p>
                        <p className="text-sm text-muted-foreground">3-4 hours, ₹150-400, buses every 30 minutes</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <Car className="h-4 w-4 text-amber-500 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">By Car</p>
                        <p className="text-sm text-muted-foreground">3 hours, 150 km via Bangalore-Mysore Highway</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-medium flex items-center gap-2 mb-2">
                    <MapPin className="h-4 w-4 text-amber-500" />
                    From Chennai
                  </h3>
                  <div className="grid grid-cols-1 gap-3">
                    <div className="flex items-start gap-2">
                      <Train className="h-4 w-4 text-amber-500 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">By Train</p>
                        <p className="text-sm text-muted-foreground">8-9 hours, ₹400-1000, several trains daily</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <Bus className="h-4 w-4 text-amber-500 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">By Bus</p>
                        <p className="text-sm text-muted-foreground">
                          8-10 hours, ₹600-1200, overnight buses available
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <Car className="h-4 w-4 text-amber-500 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">By Flight</p>
                        <p className="text-sm text-muted-foreground">Flight to Bangalore + 3 hours by road</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-medium flex items-center gap-2 mb-2">
                    <MapPin className="h-4 w-4 text-amber-500" />
                    From Mumbai
                  </h3>
                  <div className="grid grid-cols-1 gap-3">
                    <div className="flex items-start gap-2">
                      <Train className="h-4 w-4 text-amber-500 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">By Train</p>
                        <p className="text-sm text-muted-foreground">24 hours, ₹800-2000, limited direct trains</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <Bus className="h-4 w-4 text-amber-500 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">By Flight</p>
                        <p className="text-sm text-muted-foreground">Flight to Bangalore + 3 hours by road</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Reaching Hampi</CardTitle>
                <CardDescription>How to reach Hampi from major cities in India</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="font-medium flex items-center gap-2 mb-2">
                    <MapPin className="h-4 w-4 text-amber-500" />
                    From Bangalore
                  </h3>
                  <div className="grid grid-cols-1 gap-3">
                    <div className="flex items-start gap-2">
                      <Train className="h-4 w-4 text-amber-500 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">By Train</p>
                        <p className="text-sm text-muted-foreground">
                          7-8 hours to Hospet, then 30 minutes to Hampi, ₹400-800
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <Bus className="h-4 w-4 text-amber-500 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">By Bus</p>
                        <p className="text-sm text-muted-foreground">6-7 hours, ₹500-1000, overnight buses available</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <Car className="h-4 w-4 text-amber-500 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">By Car</p>
                        <p className="text-sm text-muted-foreground">6 hours, 350 km via NH48 and NH50</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-medium flex items-center gap-2 mb-2">
                    <MapPin className="h-4 w-4 text-amber-500" />
                    From Hyderabad
                  </h3>
                  <div className="grid grid-cols-1 gap-3">
                    <div className="flex items-start gap-2">
                      <Train className="h-4 w-4 text-amber-500 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">By Train</p>
                        <p className="text-sm text-muted-foreground">
                          10-12 hours to Hospet, then 30 minutes to Hampi, ₹500-1000
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <Bus className="h-4 w-4 text-amber-500 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">By Bus</p>
                        <p className="text-sm text-muted-foreground">
                          8-10 hours, ₹600-1200, overnight buses available
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <Car className="h-4 w-4 text-amber-500 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">By Car</p>
                        <p className="text-sm text-muted-foreground">8 hours, 380 km via NH44 and NH50</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-medium flex items-center gap-2 mb-2">
                    <MapPin className="h-4 w-4 text-amber-500" />
                    From Goa
                  </h3>
                  <div className="grid grid-cols-1 gap-3">
                    <div className="flex items-start gap-2">
                      <Train className="h-4 w-4 text-amber-500 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">By Train</p>
                        <p className="text-sm text-muted-foreground">
                          8-9 hours to Hospet, then 30 minutes to Hampi, ₹400-800
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <Bus className="h-4 w-4 text-amber-500 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">By Bus</p>
                        <p className="text-sm text-muted-foreground">7-8 hours, ₹500-1000, limited direct buses</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <Car className="h-4 w-4 text-amber-500 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">By Car</p>
                        <p className="text-sm text-muted-foreground">7 hours, 330 km via NH4 and NH50</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      <div className="mb-16">
        <h2 className="text-2xl font-bold mb-6">Travel Tips</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Best Time to Travel</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                October to March is the ideal time to visit both Mysore and Hampi. The weather is pleasant, and you can
                explore comfortably. Avoid the monsoon season (June to September) in Hampi as the ruins can be slippery.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Packing Essentials</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Comfortable walking shoes, light cotton clothes, sunscreen, hat, sunglasses, water bottle, and a small
                backpack. For Hampi, also pack a flashlight, insect repellent, and a light jacket for evenings.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Safety Considerations</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Both cities are generally safe for tourists. Keep valuables secure, use registered transportation, and
                be cautious when exploring remote areas in Hampi, especially during early mornings or late evenings.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="text-center">
        <Link href="/planner">
          <Button size="lg" className="gap-2">
            Plan Your Itinerary Now <ArrowRight className="h-4 w-4" />
          </Button>
        </Link>
        <p className="text-sm text-muted-foreground mt-4">
          Create a personalized travel plan based on your preferences and interests
        </p>
      </div>
    </div>
  )
}
