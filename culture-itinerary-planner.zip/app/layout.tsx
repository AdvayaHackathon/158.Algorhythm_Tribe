import type React from "react"
import { ThemeProvider } from "@/components/theme-provider"
import { ModeToggle } from "@/components/mode-toggle"
import { Toaster } from "@/components/ui/toaster"
import Link from "next/link"
import { Home, MapPin, Utensils, Bus, Calendar, MessageSquare } from "lucide-react"
import "./globals.css"

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem disableTransitionOnChange>
          <div className="min-h-screen flex flex-col">
            <header className="border-b">
              <div className="container mx-auto px-4 py-4 flex justify-between items-center">
                <Link href="/" className="flex items-center gap-2">
                  <span className="font-bold text-xl bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">
                    Heritage Explorer
                  </span>
                </Link>
                <nav className="hidden md:flex items-center gap-6">
                  <Link
                    href="/"
                    className="flex items-center gap-1 text-sm font-medium hover:text-amber-500 transition-colors"
                  >
                    <Home className="h-4 w-4" />
                    Home
                  </Link>
                  <Link
                    href="/explore"
                    className="flex items-center gap-1 text-sm font-medium hover:text-amber-500 transition-colors"
                  >
                    <MapPin className="h-4 w-4" />
                    Explore
                  </Link>
                  <Link
                    href="/food"
                    className="flex items-center gap-1 text-sm font-medium hover:text-amber-500 transition-colors"
                  >
                    <Utensils className="h-4 w-4" />
                    Food
                  </Link>
                  <Link
                    href="/travel"
                    className="flex items-center gap-1 text-sm font-medium hover:text-amber-500 transition-colors"
                  >
                    <Bus className="h-4 w-4" />
                    Travel
                  </Link>
                  <Link
                    href="/planner"
                    className="flex items-center gap-1 text-sm font-medium hover:text-amber-500 transition-colors"
                  >
                    <Calendar className="h-4 w-4" />
                    Planner
                  </Link>
                  <Link
                    href="/chat"
                    className="flex items-center gap-1 text-sm font-medium hover:text-amber-500 transition-colors"
                  >
                    <MessageSquare className="h-4 w-4" />
                    Chat
                  </Link>
                </nav>
                <div className="flex items-center gap-4">
                  <ModeToggle />
                </div>
              </div>
            </header>
            <main className="flex-1">{children}</main>
            <footer className="border-t py-6">
              <div className="container mx-auto px-4">
                <div className="flex flex-col md:flex-row justify-between items-center">
                  <p className="text-sm text-muted-foreground">
                    © {new Date().getFullYear()} Heritage Explorer. All rights reserved.
                  </p>
                  <div className="flex items-center gap-4 mt-4 md:mt-0">
                    <Link
                      href="/about"
                      className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      About
                    </Link>
                    <Link
                      href="/contact"
                      className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      Contact
                    </Link>
                    <Link
                      href="/privacy"
                      className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      Privacy
                    </Link>
                  </div>
                </div>
              </div>
            </footer>
            <Toaster />
          </div>
        </ThemeProvider>
      </body>
    </html>
  )
}


import './globals.css'

export const metadata = {
      generator: 'v0.dev'
    };
