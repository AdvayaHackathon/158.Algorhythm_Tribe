import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowRight, MapPin, Utensils, Bus, MessageSquare } from "lucide-react"

export default function Home() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col items-center text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">
          Indian Heritage Cities Explorer
        </h1>
        <p className="text-lg text-muted-foreground max-w-2xl">
          Discover the rich cultural heritage of Mysore and Hampi with personalized itineraries and local insights for
          an unforgettable journey.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
        <Card className="overflow-hidden">
          <div className="h-64 overflow-hidden">
            <img
              src="/placeholder.svg?height=400&width=600"
              alt="Mysore Palace illuminated at night"
              className="w-full h-full object-cover transition-transform hover:scale-105 duration-500"
            />
          </div>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5 text-amber-500" />
              Mysore
            </CardTitle>
            <CardDescription>
              The cultural capital of Karnataka with royal heritage and magnificent palaces
            </CardDescription>
          </CardHeader>
          <CardFooter>
            <Link href="/explore/mysore" className="w-full">
              <Button className="w-full">
                Explore Mysore <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </CardFooter>
        </Card>

        <Card className="overflow-hidden">
          <div className="h-64 overflow-hidden">
            <img
              src="/placeholder.svg?height=400&width=600"
              alt="Ancient ruins of Hampi"
              className="w-full h-full object-cover transition-transform hover:scale-105 duration-500"
            />
          </div>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5 text-amber-500" />
              Hampi
            </CardTitle>
            <CardDescription>
              A UNESCO World Heritage Site with stunning ancient ruins and boulder landscapes
            </CardDescription>
          </CardHeader>
          <CardFooter>
            <Link href="/explore/hampi" className="w-full">
              <Button className="w-full">
                Explore Hampi <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </CardFooter>
        </Card>
      </div>

      <Tabs defaultValue="features" className="w-full mb-16">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="features">Features</TabsTrigger>
          <TabsTrigger value="explore">Explore</TabsTrigger>
          <TabsTrigger value="food">Food</TabsTrigger>
          <TabsTrigger value="travel">Travel</TabsTrigger>
        </TabsList>
        <TabsContent value="features" className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-amber-500" />
                  Explore Attractions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>Discover the most iconic landmarks and hidden gems in Mysore and Hampi with detailed information.</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Utensils className="h-5 w-5 text-amber-500" />
                  Local Cuisine
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>
                  Find the best restaurants and must-try dishes that showcase the authentic flavors of these heritage
                  cities.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bus className="h-5 w-5 text-amber-500" />
                  Travel Information
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>
                  Get comprehensive transportation details within and between cities to plan your journey efficiently.
                </p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        <TabsContent value="explore" className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Mysore Highlights</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="list-disc pl-5 space-y-2">
                  <li>Mysore Palace - The magnificent royal residence</li>
                  <li>Chamundi Hills - Sacred hill with panoramic views</li>
                  <li>Brindavan Gardens - Beautiful terraced gardens</li>
                  <li>St. Philomena's Church - Neo-Gothic architecture</li>
                  <li>Rail Museum - Heritage railway exhibits</li>
                </ul>
              </CardContent>
              <CardFooter>
                <Link href="/explore/mysore" className="w-full">
                  <Button variant="outline" className="w-full">
                    View All Attractions
                  </Button>
                </Link>
              </CardFooter>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Hampi Highlights</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="list-disc pl-5 space-y-2">
                  <li>Virupaksha Temple - Ancient temple complex</li>
                  <li>Vittala Temple - Famous stone chariot</li>
                  <li>Hampi Bazaar - Historic market street</li>
                  <li>Elephant Stables - Royal elephant housing</li>
                  <li>Lotus Mahal - Indo-Islamic architecture</li>
                </ul>
              </CardContent>
              <CardFooter>
                <Link href="/explore/hampi" className="w-full">
                  <Button variant="outline" className="w-full">
                    View All Attractions
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
        <TabsContent value="food" className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Mysore Cuisine</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="list-disc pl-5 space-y-2">
                  <li>Mylari Dosa Hotel - Famous for soft butter dosas</li>
                  <li>RRR - Authentic South Indian thalis</li>
                  <li>Hotel Ruchi - Traditional Karnataka meals</li>
                  <li>Depth N Green - Vegetarian specialties</li>
                </ul>
              </CardContent>
              <CardFooter>
                <Link href="/food/mysore" className="w-full">
                  <Button variant="outline" className="w-full">
                    Explore Food Options
                  </Button>
                </Link>
              </CardFooter>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Hampi Cuisine</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="list-disc pl-5 space-y-2">
                  <li>Mango Tree - Riverside dining experience</li>
                  <li>Gopi Guest House - Local and international cuisine</li>
                  <li>The Laughing Buddha Café - Relaxed atmosphere</li>
                </ul>
              </CardContent>
              <CardFooter>
                <Link href="/food/hampi" className="w-full">
                  <Button variant="outline" className="w-full">
                    Explore Food Options
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
        <TabsContent value="travel" className="p-4">
          <Card>
            <CardHeader>
              <CardTitle>Transportation Options</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold text-lg">Within Mysore:</h3>
                  <p>Auto-rickshaws, city buses, rental bicycles, and walking tours</p>
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Within Hampi:</h3>
                  <p>Auto-rickshaws, bicycles, coracles (boat), and walking trails</p>
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Between Mysore and Hampi:</h3>
                  <p>Train (8-10 hours), Bus (7-8 hours), Taxi (6-7 hours)</p>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Link href="/travel" className="w-full">
                <Button variant="outline" className="w-full">
                  Detailed Travel Information
                </Button>
              </Link>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5 text-amber-500" />
              Personalized Itinerary
            </CardTitle>
            <CardDescription>Create a custom travel plan based on your preferences and interests</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="mb-4">
              Select your trip duration, interests, budget, and preferred activities to get a tailored itinerary for
              your visit.
            </p>
          </CardContent>
          <CardFooter>
            <Link href="/planner" className="w-full">
              <Button className="w-full">
                Plan Your Trip <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5 text-amber-500" />
              Chat Assistant
            </CardTitle>
            <CardDescription>Get instant answers to your questions about Mysore and Hampi</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="mb-4">
              Ask our AI assistant about attractions, food recommendations, travel tips, or historical information.
            </p>
          </CardContent>
          <CardFooter>
            <Link href="/chat" className="w-full">
              <Button className="w-full">
                Chat Now <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
