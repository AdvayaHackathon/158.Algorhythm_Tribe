"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Send, Bot, User, Sparkles } from "lucide-react"

// Define the message type
type Message = {
  id: string
  content: string
  role: "user" | "assistant"
  timestamp: Date
}

// Function to generate a response based on the user's query
const generateResponse = (query: string): string => {
  const lowerQuery = query.toLowerCase()

  // Check for greetings
  if (lowerQuery.includes("hello") || lowerQuery.includes("hi") || lowerQuery === "hey") {
    return "Hello! I'm your Heritage Explorer assistant. I can help you with information about Mysore and Hampi, suggest itineraries, or answer questions about attractions, food, and travel. How can I assist you today?"
  }

  // Check for specific queries about Mysore
  if (lowerQuery.includes("mysore palace")) {
    return "Mysore Palace is the official residence of the Wadiyar dynasty and one of India's most famous attractions. Built in Indo-Saracenic style, it features intricate architecture, beautiful paintings, and royal artifacts. Don't miss the palace illumination on Sunday evenings when approximately 100,000 light bulbs illuminate the palace."
  }

  if (lowerQuery.includes("best place") && lowerQuery.includes("dosa") && lowerQuery.includes("mysore")) {
    return "The best place to eat authentic dosa in Mysore is Mylari Dosa Hotel, a legendary eatery famous for its soft butter dosas that melt in your mouth. Located at Nazarbad Main Road, this small, unassuming place has been serving its signature dosas for decades. Their dosas are smaller than the standard ones but are incredibly soft and flavorful."
  }

  // Check for specific queries about Hampi
  if (
    (lowerQuery.includes("hampi") && lowerQuery.includes("2 day")) ||
    (lowerQuery.includes("2-day") && lowerQuery.includes("hampi"))
  ) {
    return "For a 2-day cultural trip to Hampi, I recommend: Day 1: Start with Virupaksha Temple in the morning, explore Hampi Bazaar, then visit the Royal Enclosure and Elephant Stables. End the day watching sunset from Matanga Hill. Day 2: Visit Vittala Temple and the Stone Chariot early morning, take a coracle ride on the Tungabhadra River, and explore the Achyutaraya Temple and riverside ruins. Don't forget to try local cuisine at Mango Tree Restaurant!"
  }

  // Check for general queries about Mysore
  if (
    lowerQuery.includes("mysore") &&
    (lowerQuery.includes("visit") || lowerQuery.includes("see") || lowerQuery.includes("attraction"))
  ) {
    return "The top attractions in Mysore include: 1. Mysore Palace - The magnificent royal residence, 2. Chamundi Hills - Sacred hill with panoramic views, 3. Brindavan Gardens - Beautiful terraced gardens with musical fountains, 4. St. Philomena's Church - Neo-Gothic architecture, 5. Rail Museum - Heritage railway exhibits. The best time to visit is from October to March when the weather is pleasant."
  }

  // Check for general queries about Hampi
  if (
    lowerQuery.includes("hampi") &&
    (lowerQuery.includes("visit") || lowerQuery.includes("see") || lowerQuery.includes("attraction"))
  ) {
    return "The must-visit attractions in Hampi include: 1. Virupaksha Temple - Ancient temple complex, 2. Vittala Temple - Famous for its stone chariot and musical pillars, 3. Hampi Bazaar - Historic market street, 4. Elephant Stables - Royal elephant housing, 5. Matanga Hill - For panoramic sunset views. Rent a bicycle to explore these scattered ruins efficiently."
  }

  // Check for food queries
  if (lowerQuery.includes("food") || lowerQuery.includes("eat") || lowerQuery.includes("restaurant")) {
    if (lowerQuery.includes("mysore")) {
      return "In Mysore, you must try: 1. Mysore Masala Dosa at Mylari Dosa Hotel, 2. Traditional South Indian thalis at RRR Restaurant, 3. Mysore Pak (sweet) from Guru Sweets, 4. Filter coffee at any local restaurant. Mysore's cuisine is influenced by the royal kitchens of the Wadiyar dynasty, featuring aromatic spices, coconut, and jaggery."
    } else if (lowerQuery.includes("hampi")) {
      return "In Hampi, recommended places to eat include: 1. Mango Tree Restaurant - Riverside dining with diverse menu, 2. Gopi Guest House - Rooftop restaurant with panoramic views, 3. The Laughing Buddha Café - Relaxed atmosphere with international cuisine. Try local specialties like Jolada Rotti (sorghum bread) with spicy brinjal curry."
    }
  }

  // Check for travel queries
  if (lowerQuery.includes("travel") || lowerQuery.includes("transportation") || lowerQuery.includes("how to reach")) {
    if (lowerQuery.includes("between") || (lowerQuery.includes("mysore") && lowerQuery.includes("hampi"))) {
      return "To travel between Mysore and Hampi (approximately 380 km): 1. By Bus: 7-8 hours, ₹500-1000, 2. By Train: Take a train from Mysore to Hospet, then a local bus to Hampi, 8-10 hours total, 3. By Taxi: 6-7 hours, ₹4000-6000 one way. Overnight buses are available and can save you accommodation costs."
    } else if (lowerQuery.includes("mysore")) {
      return "To reach Mysore: From Bangalore - 3-4 hours by road or train. The city has its own railway station and is well-connected by buses. Within Mysore, you can use city buses, auto-rickshaws, or rent bicycles/scooters to get around. App-based cab services like Ola and Uber also operate in the city."
    } else if (lowerQuery.includes("hampi")) {
      return "To reach Hampi: The nearest railway station is Hospet (13 km away). From Hospet, you can take a local bus or auto-rickshaw to Hampi. Within Hampi, the best ways to explore are by bicycle, auto-rickshaw, or coracle boats to cross the river. The ruins are spread across a large area, so having your own transportation makes exploration easier."
    }
  }

  // Check for itinerary queries
  if (lowerQuery.includes("itinerary") || lowerQuery.includes("plan") || lowerQuery.includes("days")) {
    if (lowerQuery.includes("mysore") && lowerQuery.includes("hampi")) {
      return "For a combined Mysore and Hampi trip, I recommend a 5-day itinerary: Days 1-2: Explore Mysore's attractions including the Palace, Chamundi Hills, and Brindavan Gardens. Day 3: Travel from Mysore to Hampi (7-8 hours journey). Days 4-5: Explore Hampi's ancient ruins, temples, and take a coracle ride on the Tungabhadra River. This gives you enough time to see the major highlights of both destinations."
    } else if (lowerQuery.includes("mysore")) {
      return "For Mysore, a 2-day itinerary works well: Day 1: Visit Mysore Palace in the morning, explore Devaraja Market in the afternoon, and see the palace illumination in the evening (if it's a Sunday). Day 2: Visit Chamundi Hills in the morning, St. Philomena's Church and Rail Museum in the afternoon, and Brindavan Gardens in the evening."
    } else if (lowerQuery.includes("hampi")) {
      return "For Hampi, a 2-3 day itinerary is ideal: Day 1: Explore Virupaksha Temple, Hampi Bazaar, and the Royal Enclosure. Day 2: Visit Vittala Temple, take a coracle ride, and watch the sunset from Matanga Hill. Day 3 (optional): Explore the less-visited ruins on the other side of the river or take a day trip to nearby Anegundi village."
    }
  }

  // Default response if no specific match is found
  return "I'm your Heritage Explorer assistant for Mysore and Hampi. I can provide information about attractions, food, travel tips, and help plan your itinerary. Could you please specify what you'd like to know about these heritage cities?"
}

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      content:
        "Hello! I'm your Heritage Explorer assistant. I can help you with information about Mysore and Hampi, suggest itineraries, or answer questions about attractions, food, and travel. How can I assist you today?",
      role: "assistant",
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Auto-scroll to the bottom when new messages are added
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const handleSendMessage = () => {
    if (input.trim() === "") return

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      content: input,
      role: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsTyping(true)

    // Simulate AI thinking time
    setTimeout(() => {
      // Generate and add AI response
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        content: generateResponse(input),
        role: "assistant",
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, aiResponse])
      setIsTyping(false)
    }, 1000)
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <Card className="h-[80vh] flex flex-col">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Avatar className="h-8 w-8 bg-amber-100">
                <AvatarFallback className="text-amber-700">
                  <Bot className="h-4 w-4" />
                </AvatarFallback>
              </Avatar>
              <div>
                <CardTitle>Heritage Explorer Assistant</CardTitle>
                <CardDescription>Ask me anything about Mysore and Hampi</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="flex-1 overflow-y-auto">
            <div className="space-y-4">
              {messages.map((message) => (
                <div key={message.id} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`flex gap-3 max-w-[80%] ${message.role === "user" ? "flex-row-reverse" : "flex-row"}`}
                  >
                    <Avatar className={`h-8 w-8 ${message.role === "assistant" ? "bg-amber-100" : "bg-primary/10"}`}>
                      <AvatarFallback>
                        {message.role === "assistant" ? (
                          <Bot className="h-4 w-4 text-amber-700" />
                        ) : (
                          <User className="h-4 w-4" />
                        )}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div
                        className={`rounded-lg p-3 ${
                          message.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted"
                        }`}
                      >
                        <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">{formatTime(message.timestamp)}</p>
                    </div>
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="flex gap-3 max-w-[80%]">
                    <Avatar className="h-8 w-8 bg-amber-100">
                      <AvatarFallback>
                        <Bot className="h-4 w-4 text-amber-700" />
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="rounded-lg p-3 bg-muted">
                        <div className="flex items-center gap-1">
                          <div className="h-2 w-2 rounded-full bg-amber-500 animate-bounce"></div>
                          <div
                            className="h-2 w-2 rounded-full bg-amber-500 animate-bounce"
                            style={{ animationDelay: "0.2s" }}
                          ></div>
                          <div
                            className="h-2 w-2 rounded-full bg-amber-500 animate-bounce"
                            style={{ animationDelay: "0.4s" }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          </CardContent>
          <CardFooter className="border-t p-4">
            <div className="flex flex-col w-full gap-2">
              <div className="flex items-center gap-2">
                <Button variant="outline" size="icon" className="shrink-0">
                  <Sparkles className="h-4 w-4" />
                  <span className="sr-only">Suggestions</span>
                </Button>
                <div className="relative flex-1">
                  <Input
                    placeholder="Ask about Mysore and Hampi..."
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={handleKeyDown}
                    className="pr-10"
                  />
                  {input.trim() === "" && (
                    <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                      <p className="text-xs text-muted-foreground">Press Enter to send</p>
                    </div>
                  )}
                </div>
                <Button size="icon" className="shrink-0" onClick={handleSendMessage} disabled={input.trim() === ""}>
                  <Send className="h-4 w-4" />
                  <span className="sr-only">Send</span>
                </Button>
              </div>
              <div className="flex flex-wrap gap-2 justify-center">
                <Button
                  variant="outline"
                  size="sm"
                  className="text-xs"
                  onClick={() => {
                    setInput("What are the top attractions in Mysore?")
                    setTimeout(() => handleSendMessage(), 100)
                  }}
                >
                  Top attractions in Mysore
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="text-xs"
                  onClick={() => {
                    setInput("Suggest a 2-day cultural trip to Hampi")
                    setTimeout(() => handleSendMessage(), 100)
                  }}
                >
                  2-day Hampi itinerary
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="text-xs"
                  onClick={() => {
                    setInput("Best place to eat authentic dosa in Mysore?")
                    setTimeout(() => handleSendMessage(), 100)
                  }}
                >
                  Food in Mysore
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="text-xs"
                  onClick={() => {
                    setInput("How to travel between Mysore and Hampi?")
                    setTimeout(() => handleSendMessage(), 100)
                  }}
                >
                  Travel information
                </Button>
              </div>
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
