"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { CalendarIcon, ArrowRight, Download, Share, Printer, MapPin } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export default function PlannerPage() {
  const { toast } = useToast()
  const [step, setStep] = useState(1)
  const [date, setDate] = useState<Date>()
  const [generatedItinerary, setGeneratedItinerary] = useState(false)

  const handleGenerateItinerary = () => {
    toast({
      title: "Itinerary Generated",
      description: "Your personalized travel plan has been created successfully.",
    })
    setGeneratedItinerary(true)
    setStep(3)
  }

  const handleSaveItinerary = () => {
    toast({
      title: "Itinerary Saved",
      description: "Your itinerary has been saved successfully.",
    })
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col items-center text-center mb-12">
        <h1 className="text-4xl font-bold tracking-tight mb-4">Personalized Itinerary Planner</h1>
        <p className="text-lg text-muted-foreground max-w-2xl">
          Create a custom travel plan based on your preferences, interests, and travel style.
        </p>
      </div>

      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <div className="flex justify-between items-center mb-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex flex-col items-center">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center mb-2 ${
                    step >= i
                      ? "bg-amber-500 text-white"
                      : "bg-gray-200 text-gray-500 dark:bg-gray-700 dark:text-gray-300"
                  }`}
                >
                  {i}
                </div>
                <span className="text-sm text-muted-foreground">
                  {i === 1 ? "Preferences" : i === 2 ? "Details" : "Itinerary"}
                </span>
              </div>
            ))}
          </div>
          <div className="w-full bg-gray-200 dark:bg-gray-700 h-2 rounded-full">
            <div
              className="bg-amber-500 h-2 rounded-full transition-all duration-300"
              style={{ width: `${(step - 1) * 50}%` }}
            ></div>
          </div>
        </div>

        {step === 1 && (
          <Card>
            <CardHeader>
              <CardTitle>Step 1: Your Travel Preferences</CardTitle>
              <CardDescription>Tell us about your travel style and interests</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label className="text-base">Which city would you like to visit?</Label>
                <RadioGroup defaultValue="both" className="grid grid-cols-3 gap-4 mt-2">
                  <div>
                    <RadioGroupItem value="mysore" id="mysore" className="peer sr-only" />
                    <Label
                      htmlFor="mysore"
                      className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-amber-500 [&:has([data-state=checked])]:border-amber-500"
                    >
                      <span>Mysore</span>
                    </Label>
                  </div>
                  <div>
                    <RadioGroupItem value="hampi" id="hampi" className="peer sr-only" />
                    <Label
                      htmlFor="hampi"
                      className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-amber-500 [&:has([data-state=checked])]:border-amber-500"
                    >
                      <span>Hampi</span>
                    </Label>
                  </div>
                  <div>
                    <RadioGroupItem value="both" id="both" className="peer sr-only" />
                    <Label
                      htmlFor="both"
                      className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-amber-500 [&:has([data-state=checked])]:border-amber-500"
                    >
                      <span>Both</span>
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              <div>
                <Label className="text-base">Trip Duration (in days)</Label>
                <Slider defaultValue={[3]} max={10} min={1} step={1} className="mt-6" />
                <div className="flex justify-between mt-2">
                  <span className="text-sm text-muted-foreground">1 day</span>
                  <span className="text-sm text-muted-foreground">10 days</span>
                </div>
              </div>

              <div>
                <Label className="text-base">Your Interests</Label>
                <div className="grid grid-cols-2 gap-4 mt-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="heritage" />
                    <label
                      htmlFor="heritage"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Heritage & History
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="nature" />
                    <label
                      htmlFor="nature"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Nature & Landscapes
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="food" />
                    <label
                      htmlFor="food"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Food & Cuisine
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="photography" />
                    <label
                      htmlFor="photography"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Photography
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="adventure" />
                    <label
                      htmlFor="adventure"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Adventure
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="spiritual" />
                    <label
                      htmlFor="spiritual"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Spiritual & Religious
                    </label>
                  </div>
                </div>
              </div>

              <div>
                <Label className="text-base">Budget Range</Label>
                <RadioGroup defaultValue="medium" className="grid grid-cols-3 gap-4 mt-2">
                  <div>
                    <RadioGroupItem value="budget" id="budget" className="peer sr-only" />
                    <Label
                      htmlFor="budget"
                      className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-amber-500 [&:has([data-state=checked])]:border-amber-500"
                    >
                      <span>Budget</span>
                    </Label>
                  </div>
                  <div>
                    <RadioGroupItem value="medium" id="medium" className="peer sr-only" />
                    <Label
                      htmlFor="medium"
                      className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-amber-500 [&:has([data-state=checked])]:border-amber-500"
                    >
                      <span>Medium</span>
                    </Label>
                  </div>
                  <div>
                    <RadioGroupItem value="luxury" id="luxury" className="peer sr-only" />
                    <Label
                      htmlFor="luxury"
                      className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-amber-500 [&:has([data-state=checked])]:border-amber-500"
                    >
                      <span>Luxury</span>
                    </Label>
                  </div>
                </RadioGroup>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full" onClick={() => setStep(2)}>
                Continue <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardFooter>
          </Card>
        )}

        {step === 2 && (
          <Card>
            <CardHeader>
              <CardTitle>Step 2: Additional Details</CardTitle>
              <CardDescription>Provide more information to customize your itinerary</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label className="text-base">Travel Dates</Label>
                <div className="grid grid-cols-2 gap-4 mt-2">
                  <div className="flex flex-col space-y-1.5">
                    <Label htmlFor="startDate">Start Date</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant={"outline"} className="w-full justify-start text-left font-normal">
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {date ? format(date, "PPP") : <span>Pick a date</span>}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
                      </PopoverContent>
                    </Popover>
                  </div>
                  <div className="flex flex-col space-y-1.5">
                    <Label htmlFor="endDate">End Date</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant={"outline"} className="w-full justify-start text-left font-normal">
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          <span>Pick a date</span>
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar mode="single" initialFocus />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>
              </div>

              <div>
                <Label className="text-base">Number of Travelers</Label>
                <div className="grid grid-cols-2 gap-4 mt-2">
                  <div className="flex flex-col space-y-1.5">
                    <Label htmlFor="adults">Adults</Label>
                    <Select defaultValue="2">
                      <SelectTrigger id="adults">
                        <SelectValue placeholder="Select" />
                      </SelectTrigger>
                      <SelectContent position="popper">
                        <SelectItem value="1">1</SelectItem>
                        <SelectItem value="2">2</SelectItem>
                        <SelectItem value="3">3</SelectItem>
                        <SelectItem value="4">4</SelectItem>
                        <SelectItem value="5+">5+</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex flex-col space-y-1.5">
                    <Label htmlFor="children">Children</Label>
                    <Select defaultValue="0">
                      <SelectTrigger id="children">
                        <SelectValue placeholder="Select" />
                      </SelectTrigger>
                      <SelectContent position="popper">
                        <SelectItem value="0">0</SelectItem>
                        <SelectItem value="1">1</SelectItem>
                        <SelectItem value="2">2</SelectItem>
                        <SelectItem value="3">3</SelectItem>
                        <SelectItem value="4+">4+</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <div>
                <Label className="text-base">Preferred Activities</Label>
                <div className="grid grid-cols-2 gap-4 mt-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="sightseeing" defaultChecked />
                    <label
                      htmlFor="sightseeing"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Sightseeing
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="shopping" />
                    <label
                      htmlFor="shopping"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Shopping
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="foodtour" defaultChecked />
                    <label
                      htmlFor="foodtour"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Food Tours
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="hiking" />
                    <label
                      htmlFor="hiking"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Hiking
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="boating" />
                    <label
                      htmlFor="boating"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Boating
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="cultural" defaultChecked />
                    <label
                      htmlFor="cultural"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Cultural Shows
                    </label>
                  </div>
                </div>
              </div>

              <div>
                <Label className="text-base" htmlFor="special-requests">
                  Special Requests or Requirements
                </Label>
                <Textarea
                  id="special-requests"
                  placeholder="Any dietary restrictions, accessibility needs, or specific places you want to visit..."
                  className="mt-2"
                />
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={() => setStep(1)}>
                Back
              </Button>
              <Button onClick={handleGenerateItinerary}>
                Generate Itinerary <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardFooter>
          </Card>
        )}

        {step === 3 && generatedItinerary && (
          <Card>
            <CardHeader>
              <CardTitle>Your Personalized Itinerary</CardTitle>
              <CardDescription>A custom travel plan based on your preferences</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="overview" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="overview">Overview</TabsTrigger>
                  <TabsTrigger value="day-by-day">Day by Day</TabsTrigger>
                  <TabsTrigger value="map">Map</TabsTrigger>
                  <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
                </TabsList>
                <TabsContent value="overview" className="p-4">
                  <div className="space-y-6">
                    <div className="bg-amber-50 dark:bg-amber-950 p-4 rounded-lg">
                      <h3 className="font-medium text-lg mb-2">Trip Summary</h3>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm font-medium">Destinations</p>
                          <p className="text-sm text-muted-foreground">Mysore and Hampi</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium">Duration</p>
                          <p className="text-sm text-muted-foreground">5 Days, 4 Nights</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium">Travel Style</p>
                          <p className="text-sm text-muted-foreground">Heritage, Food, Photography</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium">Budget Category</p>
                          <p className="text-sm text-muted-foreground">Medium</p>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h3 className="font-medium text-lg mb-2">Itinerary Highlights</h3>
                      <ul className="space-y-2">
                        <li className="flex items-start gap-2">
                          <div className="bg-amber-100 dark:bg-amber-900 rounded-full p-1 mt-0.5">
                            <span className="text-amber-800 dark:text-amber-100 text-xs font-bold">1</span>
                          </div>
                          <div>
                            <p className="font-medium">Explore the magnificent Mysore Palace</p>
                            <p className="text-sm text-muted-foreground">
                              Visit during the evening illumination for a magical experience
                            </p>
                          </div>
                        </li>
                        <li className="flex items-start gap-2">
                          <div className="bg-amber-100 dark:bg-amber-900 rounded-full p-1 mt-0.5">
                            <span className="text-amber-800 dark:text-amber-100 text-xs font-bold">2</span>
                          </div>
                          <div>
                            <p className="font-medium">Discover the ancient ruins of Hampi</p>
                            <p className="text-sm text-muted-foreground">
                              Explore the UNESCO World Heritage Site with its stunning temples and monuments
                            </p>
                          </div>
                        </li>
                        <li className="flex items-start gap-2">
                          <div className="bg-amber-100 dark:bg-amber-900 rounded-full p-1 mt-0.5">
                            <span className="text-amber-800 dark:text-amber-100 text-xs font-bold">3</span>
                          </div>
                          <div>
                            <p className="font-medium">Taste authentic local cuisine</p>
                            <p className="text-sm text-muted-foreground">
                              From Mysore's royal delicacies to Hampi's riverside dining experiences
                            </p>
                          </div>
                        </li>
                        <li className="flex items-start gap-2">
                          <div className="bg-amber-100 dark:bg-amber-900 rounded-full p-1 mt-0.5">
                            <span className="text-amber-800 dark:text-amber-100 text-xs font-bold">4</span>
                          </div>
                          <div>
                            <p className="font-medium">Enjoy a coracle ride on the Tungabhadra River</p>
                            <p className="text-sm text-muted-foreground">
                              A unique perspective of Hampi's boulder-strewn landscape
                            </p>
                          </div>
                        </li>
                        <li className="flex items-start gap-2">
                          <div className="bg-amber-100 dark:bg-amber-900 rounded-full p-1 mt-0.5">
                            <span className="text-amber-800 dark:text-amber-100 text-xs font-bold">5</span>
                          </div>
                          <div>
                            <p className="font-medium">Witness the panoramic view from Chamundi Hills</p>
                            <p className="text-sm text-muted-foreground">
                              Overlooking the city of Mysore with its royal heritage
                            </p>
                          </div>
                        </li>
                      </ul>
                    </div>

                    <div>
                      <h3 className="font-medium text-lg mb-2">Estimated Budget</h3>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base">Accommodation</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p className="text-2xl font-bold">₹12,000</p>
                            <p className="text-sm text-muted-foreground">4 nights, mid-range hotels</p>
                          </CardContent>
                        </Card>
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base">Transportation</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p className="text-2xl font-bold">₹8,000</p>
                            <p className="text-sm text-muted-foreground">Including intercity travel</p>
                          </CardContent>
                        </Card>
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base">Food & Activities</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p className="text-2xl font-bold">₹10,000</p>
                            <p className="text-sm text-muted-foreground">Meals, entry fees, guides</p>
                          </CardContent>
                        </Card>
                      </div>
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="day-by-day" className="p-4">
                  <div className="space-y-6">
                    <div className="border rounded-lg overflow-hidden">
                      <div className="bg-amber-100 dark:bg-amber-900 p-3">
                        <h3 className="font-medium">Day 1: Arrival in Mysore</h3>
                      </div>
                      <div className="p-4 space-y-4">
                        <div>
                          <h4 className="text-sm font-medium">Morning</h4>
                          <p className="text-sm text-muted-foreground">
                            Arrive in Mysore and check into your hotel. Rest and refresh.
                          </p>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium">Afternoon</h4>
                          <p className="text-sm text-muted-foreground">
                            Visit Devaraja Market to experience local culture and shop for souvenirs.
                          </p>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium">Evening</h4>
                          <p className="text-sm text-muted-foreground">
                            Explore Mysore Palace during the evening illumination (Sunday or public holiday). Dinner at
                            a traditional restaurant.
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="border rounded-lg overflow-hidden">
                      <div className="bg-amber-100 dark:bg-amber-900 p-3">
                        <h3 className="font-medium">Day 2: Mysore Exploration</h3>
                      </div>
                      <div className="p-4 space-y-4">
                        <div>
                          <h4 className="text-sm font-medium">Morning</h4>
                          <p className="text-sm text-muted-foreground">
                            Visit Mysore Palace for a detailed tour. Explore Chamundi Hills and the temple.
                          </p>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium">Afternoon</h4>
                          <p className="text-sm text-muted-foreground">
                            Lunch at Mylari Dosa Hotel. Visit St. Philomena's Church and the Rail Museum.
                          </p>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium">Evening</h4>
                          <p className="text-sm text-muted-foreground">
                            Enjoy the beautiful Brindavan Gardens and the musical fountain show. Dinner at RRR
                            Restaurant.
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="border rounded-lg overflow-hidden">
                      <div className="bg-amber-100 dark:bg-amber-900 p-3">
                        <h3 className="font-medium">Day 3: Travel to Hampi</h3>
                      </div>
                      <div className="p-4 space-y-4">
                        <div>
                          <h4 className="text-sm font-medium">Morning</h4>
                          <p className="text-sm text-muted-foreground">
                            Early morning departure from Mysore to Hampi by bus or car (7-8 hours journey).
                          </p>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium">Afternoon</h4>
                          <p className="text-sm text-muted-foreground">Lunch en route. Continue journey to Hampi.</p>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium">Evening</h4>
                          <p className="text-sm text-muted-foreground">
                            Arrive in Hampi and check into your accommodation. Relax and enjoy dinner at Mango Tree
                            Restaurant by the riverside.
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="border rounded-lg overflow-hidden">
                      <div className="bg-amber-100 dark:bg-amber-900 p-3">
                        <h3 className="font-medium">Day 4: Hampi Exploration</h3>
                      </div>
                      <div className="p-4 space-y-4">
                        <div>
                          <h4 className="text-sm font-medium">Morning</h4>
                          <p className="text-sm text-muted-foreground">
                            Rent bicycles and visit Virupaksha Temple and Hampi Bazaar. Explore the Royal Enclosure and
                            Elephant Stables.
                          </p>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium">Afternoon</h4>
                          <p className="text-sm text-muted-foreground">
                            Lunch at Gopi Guest House. Visit the Vittala Temple and the famous Stone Chariot.
                          </p>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium">Evening</h4>
                          <p className="text-sm text-muted-foreground">
                            Climb Matanga Hill for sunset views. Dinner at The Laughing Buddha Café.
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="border rounded-lg overflow-hidden">
                      <div className="bg-amber-100 dark:bg-amber-900 p-3">
                        <h3 className="font-medium">Day 5: Hampi to Departure</h3>
                      </div>
                      <div className="p-4 space-y-4">
                        <div>
                          <h4 className="text-sm font-medium">Morning</h4>
                          <p className="text-sm text-muted-foreground">
                            Take a coracle ride on the Tungabhadra River. Visit any remaining sites of interest.
                          </p>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium">Afternoon</h4>
                          <p className="text-sm text-muted-foreground">
                            Lunch at Mango Tree Restaurant. Start your journey back or to your next destination.
                          </p>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium">Evening</h4>
                          <p className="text-sm text-muted-foreground">
                            Departure from Hampi with wonderful memories of your heritage city tour.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="map" className="p-4">
                  <div className="space-y-6">
                    <div className="border rounded-lg overflow-hidden">
                      <div className="bg-gray-100 dark:bg-gray-800 p-4 h-96 flex items-center justify-center">
                        <div className="text-center">
                          <MapPin className="h-12 w-12 text-amber-500 mx-auto mb-4" />
                          <p className="text-muted-foreground">Interactive map will be displayed here</p>
                          <p className="text-sm text-muted-foreground mt-2">
                            Showing routes between Mysore and Hampi with all points of interest
                          </p>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h3 className="font-medium text-lg mb-4">Key Locations</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-lg">Mysore</CardTitle>
                          </CardHeader>
                          <CardContent className="space-y-2">
                            <div className="flex items-start gap-2">
                              <MapPin className="h-4 w-4 text-amber-500 mt-0.5" />
                              <div>
                                <p className="text-sm font-medium">Mysore Palace</p>
                                <p className="text-xs text-muted-foreground">Sayyaji Rao Road, Mysore</p>
                              </div>
                            </div>
                            <div className="flex items-start gap-2">
                              <MapPin className="h-4 w-4 text-amber-500 mt-0.5" />
                              <div>
                                <p className="text-sm font-medium">Chamundi Hills</p>
                                <p className="text-xs text-muted-foreground">Chamundi Hills, Mysore</p>
                              </div>
                            </div>
                            <div className="flex items-start gap-2">
                              <MapPin className="h-4 w-4 text-amber-500 mt-0.5" />
                              <div>
                                <p className="text-sm font-medium">Brindavan Gardens</p>
                                <p className="text-xs text-muted-foreground">Krishna Raja Sagara Dam, Mysore</p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>

                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-lg">Hampi</CardTitle>
                          </CardHeader>
                          <CardContent className="space-y-2">
                            <div className="flex items-start gap-2">
                              <MapPin className="h-4 w-4 text-amber-500 mt-0.5" />
                              <div>
                                <p className="text-sm font-medium">Virupaksha Temple</p>
                                <p className="text-xs text-muted-foreground">Hampi Bazaar, Hampi</p>
                              </div>
                            </div>
                            <div className="flex items-start gap-2">
                              <MapPin className="h-4 w-4 text-amber-500 mt-0.5" />
                              <div>
                                <p className="text-sm font-medium">Vittala Temple</p>
                                <p className="text-xs text-muted-foreground">Vittala Temple Road, Hampi</p>
                              </div>
                            </div>
                            <div className="flex items-start gap-2">
                              <MapPin className="h-4 w-4 text-amber-500 mt-0.5" />
                              <div>
                                <p className="text-sm font-medium">Matanga Hill</p>
                                <p className="text-xs text-muted-foreground">Near Hampi Bazaar, Hampi</p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="recommendations" className="p-4">
                  <div className="space-y-6">
                    <div>
                      <h3 className="font-medium text-lg mb-4">Recommended Accommodations</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base">Mysore</CardTitle>
                          </CardHeader>
                          <CardContent className="space-y-3">
                            <div>
                              <p className="text-sm font-medium">Royal Orchid Metropole</p>
                              <p className="text-xs text-muted-foreground">Heritage hotel with colonial architecture</p>
                              <p className="text-xs">₹3,500 - ₹5,000 per night</p>
                            </div>
                            <div>
                              <p className="text-sm font-medium">Hotel Sandesh The Prince</p>
                              <p className="text-xs text-muted-foreground">Modern hotel with good amenities</p>
                              <p className="text-xs">₹2,500 - ₹4,000 per night</p>
                            </div>
                            <div>
                              <p className="text-sm font-medium">Hotel Mayura Hoysala</p>
                              <p className="text-xs text-muted-foreground">Budget-friendly option near attractions</p>
                              <p className="text-xs">₹1,500 - ₹2,500 per night</p>
                            </div>
                          </CardContent>
                        </Card>

                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base">Hampi</CardTitle>
                          </CardHeader>
                          <CardContent className="space-y-3">
                            <div>
                              <p className="text-sm font-medium">Evolve Back, Hampi</p>
                              <p className="text-xs text-muted-foreground">
                                Luxury resort inspired by Vijayanagara architecture
                              </p>
                              <p className="text-xs">₹15,000 - ₹25,000 per night</p>
                            </div>
                            <div>
                              <p className="text-sm font-medium">Hampi Heritage Resort</p>
                              <p className="text-xs text-muted-foreground">Mid-range option with good views</p>
                              <p className="text-xs">₹3,000 - ₹5,000 per night</p>
                            </div>
                            <div>
                              <p className="text-sm font-medium">Shanthi Guest House</p>
                              <p className="text-xs text-muted-foreground">Budget-friendly option near Hampi Bazaar</p>
                              <p className="text-xs">₹800 - ₹1,500 per night</p>
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    </div>

                    <div>
                      <h3 className="font-medium text-lg mb-4">Packing Recommendations</h3>
                      <Card>
                        <CardContent className="pt-6">
                          <ul className="space-y-2">
                            <li className="flex items-start gap-2">
                              <div className="bg-amber-100 dark:bg-amber-900 rounded-full p-1 mt-0.5">
                                <span className="text-amber-800 dark:text-amber-100 text-xs font-bold">✓</span>
                              </div>
                              <div>
                                <p className="font-medium">Comfortable walking shoes</p>
                                <p className="text-sm text-muted-foreground">
                                  Both cities require a lot of walking on uneven terrain
                                </p>
                              </div>
                            </li>
                            <li className="flex items-start gap-2">
                              <div className="bg-amber-100 dark:bg-amber-900 rounded-full p-1 mt-0.5">
                                <span className="text-amber-800 dark:text-amber-100 text-xs font-bold">✓</span>
                              </div>
                              <div>
                                <p className="font-medium">Light cotton clothes</p>
                                <p className="text-sm text-muted-foreground">
                                  Weather is generally warm, especially in Hampi
                                </p>
                              </div>
                            </li>
                            <li className="flex items-start gap-2">
                              <div className="bg-amber-100 dark:bg-amber-900 rounded-full p-1 mt-0.5">
                                <span className="text-amber-800 dark:text-amber-100 text-xs font-bold">✓</span>
                              </div>
                              <div>
                                <p className="font-medium">Sun protection</p>
                                <p className="text-sm text-muted-foreground">
                                  Hat, sunglasses, and sunscreen are essential, especially in Hampi
                                </p>
                              </div>
                            </li>
                            <li className="flex items-start gap-2">
                              <div className="bg-amber-100 dark:bg-amber-900 rounded-full p-1 mt-0.5">
                                <span className="text-amber-800 dark:text-amber-100 text-xs font-bold">✓</span>
                              </div>
                              <div>
                                <p className="font-medium">Water bottle</p>
                                <p className="text-sm text-muted-foreground">Stay hydrated while exploring</p>
                              </div>
                            </li>
                            <li className="flex items-start gap-2">
                              <div className="bg-amber-100 dark:bg-amber-900 rounded-full p-1 mt-0.5">
                                <span className="text-amber-800 dark:text-amber-100 text-xs font-bold">✓</span>
                              </div>
                              <div>
                                <p className="font-medium">Camera</p>
                                <p className="text-sm text-muted-foreground">
                                  Both cities offer amazing photography opportunities
                                </p>
                              </div>
                            </li>
                          </ul>
                        </CardContent>
                      </Card>
                    </div>

                    <div>
                      <h3 className="font-medium text-lg mb-4">Travel Tips</h3>
                      <Card>
                        <CardContent className="pt-6">
                          <ul className="space-y-2">
                            <li className="flex items-start gap-2">
                              <div className="bg-amber-100 dark:bg-amber-900 rounded-full p-1 mt-0.5">
                                <span className="text-amber-800 dark:text-amber-100 text-xs font-bold">!</span>
                              </div>
                              <div>
                                <p className="font-medium">Best time to visit</p>
                                <p className="text-sm text-muted-foreground">
                                  October to March is ideal for both destinations
                                </p>
                              </div>
                            </li>
                            <li className="flex items-start gap-2">
                              <div className="bg-amber-100 dark:bg-amber-900 rounded-full p-1 mt-0.5">
                                <span className="text-amber-800 dark:text-amber-100 text-xs font-bold">!</span>
                              </div>
                              <div>
                                <p className="font-medium">Local transportation</p>
                                <p className="text-sm text-muted-foreground">
                                  Use auto-rickshaws in Mysore and bicycles in Hampi for the best experience
                                </p>
                              </div>
                            </li>
                            <li className="flex items-start gap-2">
                              <div className="bg-amber-100 dark:bg-amber-900 rounded-full p-1 mt-0.5">
                                <span className="text-amber-800 dark:text-amber-100 text-xs font-bold">!</span>
                              </div>
                              <div>
                                <p className="font-medium">Cash availability</p>
                                <p className="text-sm text-muted-foreground">
                                  Carry sufficient cash in Hampi as ATMs are limited
                                </p>
                              </div>
                            </li>
                          </ul>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
            <CardFooter className="flex flex-wrap gap-4">
              <Button variant="outline" className="flex-1" onClick={handleSaveItinerary}>
                <Download className="mr-2 h-4 w-4" />
                Save Itinerary
              </Button>
              <Button variant="outline" className="flex-1">
                <Printer className="mr-2 h-4 w-4" />
                Print
              </Button>
              <Button variant="outline" className="flex-1">
                <Share className="mr-2 h-4 w-4" />
                Share
              </Button>
              <Button className="flex-1">
                <ArrowRight className="mr-2 h-4 w-4" />
                Book Now
              </Button>
            </CardFooter>
          </Card>
        )}
      </div>
    </div>
  )
}
