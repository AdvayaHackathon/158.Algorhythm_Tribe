import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { MapPin, ArrowRight } from "lucide-react"

export default function ExplorePage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col items-center text-center mb-12">
        <h1 className="text-4xl font-bold tracking-tight mb-4">Explore Heritage Cities</h1>
        <p className="text-lg text-muted-foreground max-w-2xl">
          Discover the rich cultural heritage, historical monuments, and natural beauty of Mysore and Hampi.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
        <Card className="overflow-hidden">
          <div className="h-64 overflow-hidden">
            <img
              src="https://i.pinimg.com/736x/5e/99/9a/5e999adda3930e5baccce0ddf25a4008.jpg?height=400&width=600"
              alt="Mysore Palace illuminated at night"
              className="w-full h-full object-cover transition-transform hover:scale-105 duration-500"
            />
          </div>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5 text-amber-500" />
              Mysore
            </CardTitle>
            <CardDescription>
              The cultural capital of Karnataka with royal heritage and magnificent palaces
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="mb-4">
              Mysore, officially Mysuru, is a city in southern India's Karnataka state. It was the capital of the
              Kingdom of Mysore from 1399 to 1947. Known for its glorious royal heritage, magnificent monuments, and
              rich cultural traditions.
            </p>
            <div className="flex flex-wrap gap-2 mb-4">
              <span className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100 text-xs px-2 py-1 rounded-full">
                Royal Heritage
              </span>
              <span className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100 text-xs px-2 py-1 rounded-full">
                Palaces
              </span>
              <span className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100 text-xs px-2 py-1 rounded-full">
                Gardens
              </span>
              <span className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100 text-xs px-2 py-1 rounded-full">
                Silk
              </span>
              <span className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100 text-xs px-2 py-1 rounded-full">
                Dasara Festival
              </span>
            </div>
          </CardContent>
          <CardFooter>
            <Link href="/explore/mysore" className="w-full">
              <Button className="w-full">
                Explore Mysore <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </CardFooter>
        </Card>

        <Card className="overflow-hidden">
          <div className="h-64 overflow-hidden">
            <img
              src="https://i.pinimg.com/474x/0f/48/43/0f48434ca2c9c608972730d5551e77d8.jpg?height=400&width=600"
              alt="Ancient ruins of Hampi"
              className="w-full h-full object-cover transition-transform hover:scale-105 duration-500"
            />
          </div>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5 text-amber-500" />
              Hampi
            </CardTitle>
            <CardDescription>
              A UNESCO World Heritage Site with stunning ancient ruins and boulder landscapes
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="mb-4">
              Hampi is an ancient village in Karnataka, India. It was the capital of the Vijayanagara Empire in the 14th
              century and is now a UNESCO World Heritage Site. The area is known for its massive stone monuments,
              temples, and ruins.
            </p>
            <div className="flex flex-wrap gap-2 mb-4">
              <span className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100 text-xs px-2 py-1 rounded-full">
                UNESCO Site
              </span>
              <span className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100 text-xs px-2 py-1 rounded-full">
                Ancient Ruins
              </span>
              <span className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100 text-xs px-2 py-1 rounded-full">
                Temples
              </span>
              <span className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100 text-xs px-2 py-1 rounded-full">
                Boulder Landscape
              </span>
              <span className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100 text-xs px-2 py-1 rounded-full">
                Tungabhadra River
              </span>
            </div>
          </CardContent>
          <CardFooter>
            <Link href="/explore/hampi" className="w-full">
              <Button className="w-full">
                Explore Hampi <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
