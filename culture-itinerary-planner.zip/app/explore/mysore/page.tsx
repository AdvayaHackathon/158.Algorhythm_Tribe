import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MapPin, Clock, Info, ArrowLeft, Bookmark } from "lucide-react"

const attractions = [
  {
    id: 1,
    name: "Mysore Palace",
    description:
      "The official residence of the Wadiyar dynasty and the seat of the Kingdom of Mysore. The palace is known for its Indo-Saracenic style of architecture.",
    image: "https://i.pinimg.com/736x/36/d1/7b/36d17b7470e2ebdd367a930a753ee1b3.jpg?height=400&width=600",
    timings: "10:00 AM - 5:30 PM",
    entryFee: "₹50 for Indians, ₹200 for Foreigners",
    location: "Sayyaji Rao Road, Mysore",
    tags: ["Palace", "Heritage", "Architecture"],
  },
  {
    id: 2,
    name: "Chamundi Hills",
    description:
      "A hill with panoramic views of Mysore city and home to the famous Chamundeshwari Temple dedicated to the patron goddess of the Mysore Maharajas.",
    image: "https://i.pinimg.com/736x/c1/f7/fa/c1f7fa34a83e46f2e21dfb029a301870.jpg?height=400&width=600",
    timings: "7:30 AM - 9:00 PM",
    entryFee: "Free (Temple entry)",
    location: "Chamundi Hills, Mysore",
    tags: ["Temple", "Viewpoint", "Nature"],
  },
  {
    id: 3,
    name: "Brindavan Gardens",
    description:
      "A symmetrical garden with botanical park, fountains, and boating facilities, located at the Krishna Raja Sagara dam.",
    image: "https://i.pinimg.com/736x/6f/a3/1a/6fa31a9054a45e2eb1b28ca8caebfa8e.jpg?height=400&width=600",
    timings: "6:30 AM - 8:00 PM",
    entryFee: "₹15 for Adults, ₹5 for Children",
    location: "Krishna Raja Sagara Dam, Mysore",
    tags: ["Garden", "Dam", "Fountains"],
  },
  {
    id: 4,
    name: "St. Philomena's Church",
    description:
      "One of the largest churches in India built in Neo-Gothic style with beautiful stained glass windows and twin spires.",
    image: "https://i.pinimg.com/736x/ad/e8/c8/ade8c87ebc491811d9b8bd06a0b357ec.jpg?height=400&width=600",
    timings: "7:00 AM - 6:00 PM",
    entryFee: "Free",
    location: "Lourdes Nagar, Mysore",
    tags: ["Church", "Architecture", "Religious"],
  },
  {
    id: 5,
    name: "Rail Museum",
    description:
      "An outdoor exhibit of vintage locomotives, coaches, and railway artifacts showcasing the evolution of Indian Railways.",
    image: "https://i.pinimg.com/736x/43/70/1a/43701a07091e8534d0e5110691877918.jpg?height=400&width=600",
    timings: "9:30 AM - 5:30 PM (Closed on Mondays)",
    entryFee: "₹20 for Adults, ₹10 for Children",
    location: "KRS Road, Mysore",
    tags: ["Museum", "Heritage", "Trains"],
  },
]

export default function MysorePage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Link
          href="/explore"
          className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-foreground mb-4"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Explore
        </Link>
        <h1 className="text-4xl font-bold tracking-tight mb-4">Explore Mysore</h1>
        <p className="text-lg text-muted-foreground max-w-3xl">
          Discover the royal city of Mysore, known for its magnificent palaces, beautiful gardens, and rich cultural
          heritage.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Best Time to Visit</CardTitle>
          </CardHeader>
          <CardContent>
            <p>October to March (Winter season)</p>
            <p className="text-sm text-muted-foreground mt-1">
              Pleasant weather with temperatures between 15°C to 30°C
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Famous For</CardTitle>
          </CardHeader>
          <CardContent>
            <p>Mysore Palace, Dasara Festival, Mysore Silk, Mysore Pak (sweet)</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Duration</CardTitle>
          </CardHeader>
          <CardContent>
            <p>2-3 days recommended</p>
            <p className="text-sm text-muted-foreground mt-1">To explore major attractions at a comfortable pace</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="attractions" className="w-full mb-16">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="attractions">Attractions</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
          <TabsTrigger value="tips">Travel Tips</TabsTrigger>
        </TabsList>
        <TabsContent value="attractions" className="p-4">
          <div className="grid grid-cols-1 gap-8">
            {attractions.map((attraction) => (
              <Card key={attraction.id} className="overflow-hidden">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="md:col-span-1">
                    <img
                      src={attraction.image || "/placeholder.svg"}
                      alt={attraction.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="md:col-span-2 p-6">
                    <div className="flex justify-between items-start">
                      <h3 className="text-xl font-bold">{attraction.name}</h3>
                      <Button variant="ghost" size="icon">
                        <Bookmark className="h-5 w-5" />
                        <span className="sr-only">Bookmark</span>
                      </Button>
                    </div>
                    <p className="text-muted-foreground mt-2 mb-4">{attraction.description}</p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div className="flex items-start gap-2">
                        <Clock className="h-5 w-5 text-amber-500 mt-0.5" />
                        <div>
                          <p className="font-medium">Timings</p>
                          <p className="text-sm text-muted-foreground">{attraction.timings}</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-2">
                        <Info className="h-5 w-5 text-amber-500 mt-0.5" />
                        <div>
                          <p className="font-medium">Entry Fee</p>
                          <p className="text-sm text-muted-foreground">{attraction.entryFee}</p>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-start gap-2 mb-4">
                      <MapPin className="h-5 w-5 text-amber-500 mt-0.5" />
                      <div>
                        <p className="font-medium">Location</p>
                        <p className="text-sm text-muted-foreground">{attraction.location}</p>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {attraction.tags.map((tag, index) => (
                        <span
                          key={index}
                          className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100 text-xs px-2 py-1 rounded-full"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="history" className="p-4">
          <Card>
            <CardHeader>
              <CardTitle>History of Mysore</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>
                Mysore, officially known as Mysuru, has a rich and storied history dating back to the 14th century. The
                city derives its name from "Mahishuru," which means the abode of Mahisha, a mythological demon.
              </p>
              <p>
                <strong>Wadiyar Dynasty:</strong> The Wadiyar dynasty ruled the Kingdom of Mysore from 1399 to 1947,
                with a brief interruption during Hyder Ali and Tipu Sultan's reign. The Wadiyars were great patrons of
                art, culture, and architecture, contributing significantly to the city's heritage.
              </p>
              <p>
                <strong>Hyder Ali and Tipu Sultan:</strong> In the 18th century, Hyder Ali, a military commander, seized
                power and established his dominance. His son, Tipu Sultan, known as the "Tiger of Mysore," continued his
                father's resistance against British colonial rule until his defeat in 1799.
              </p>
              <p>
                <strong>British Era:</strong> After Tipu Sultan's defeat, the British restored the Wadiyar dynasty as
                puppet rulers. During this period, Mysore developed as a planned city with wide roads, public buildings,
                and the famous Mysore Palace was rebuilt after a fire in 1897.
              </p>
              <p>
                <strong>Post-Independence:</strong> After India's independence in 1947, Mysore became a part of
                Karnataka state. The city has preserved its cultural heritage while evolving into a modern urban center
                known for education, IT, and tourism.
              </p>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="tips" className="p-4">
          <Card>
            <CardHeader>
              <CardTitle>Travel Tips for Mysore</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-4">
                <li className="flex items-start gap-2">
                  <div className="bg-amber-100 dark:bg-amber-900 rounded-full p-1 mt-0.5">
                    <span className="text-amber-800 dark:text-amber-100 text-xs font-bold">1</span>
                  </div>
                  <div>
                    <p className="font-medium">Visit Mysore Palace during the evening illumination</p>
                    <p className="text-sm text-muted-foreground">
                      The palace is illuminated on Sundays and public holidays from 7:00 PM to 8:00 PM, creating a
                      magical atmosphere.
                    </p>
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <div className="bg-amber-100 dark:bg-amber-900 rounded-full p-1 mt-0.5">
                    <span className="text-amber-800 dark:text-amber-100 text-xs font-bold">2</span>
                  </div>
                  <div>
                    <p className="font-medium">Plan your visit during Dasara festival (October)</p>
                    <p className="text-sm text-muted-foreground">
                      Experience the grand celebrations with processions, cultural events, and the illuminated palace.
                    </p>
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <div className="bg-amber-100 dark:bg-amber-900 rounded-full p-1 mt-0.5">
                    <span className="text-amber-800 dark:text-amber-100 text-xs font-bold">3</span>
                  </div>
                  <div>
                    <p className="font-medium">Use local transportation</p>
                    <p className="text-sm text-muted-foreground">
                      Auto-rickshaws and city buses are convenient for getting around. Consider renting a bicycle for a
                      more immersive experience.
                    </p>
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <div className="bg-amber-100 dark:bg-amber-900 rounded-full p-1 mt-0.5">
                    <span className="text-amber-800 dark:text-amber-100 text-xs font-bold">4</span>
                  </div>
                  <div>
                    <p className="font-medium">Shop for local specialties</p>
                    <p className="text-sm text-muted-foreground">
                      Don't miss Mysore Silk sarees, sandalwood products, and Mysore Pak (traditional sweet).
                    </p>
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <div className="bg-amber-100 dark:bg-amber-900 rounded-full p-1 mt-0.5">
                    <span className="text-amber-800 dark:text-amber-100 text-xs font-bold">5</span>
                  </div>
                  <div>
                    <p className="font-medium">Try local cuisine</p>
                    <p className="text-sm text-muted-foreground">
                      Sample Mysore Masala Dosa, Mysore Pak, and filter coffee at local restaurants.
                    </p>
                  </div>
                </li>
              </ul>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
