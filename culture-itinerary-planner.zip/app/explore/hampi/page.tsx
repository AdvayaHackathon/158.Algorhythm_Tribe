import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MapPin, Clock, Info, ArrowLeft, Bookmark } from "lucide-react"

const attractions = [
  {
    id: 1,
    name: "Virupaksha Temple",
    description:
      "The oldest and most revered temple in Hampi, dedicated to Lord Shiva. It features a 160-foot high gopuram (tower) and is still an active place of worship.",
    image: "https://i.pinimg.com/736x/7a/3e/dd/7a3edd981ff9d61311a02b2c2737f6ad.jpg?height=400&width=600",
    timings: "6:00 AM - 6:00 PM",
    entryFee: "₹10",
    location: "Hampi Bazaar, Hampi",
    tags: ["Temple", "Heritage", "Religious"],
  },
  {
    id: 2,
    name: "Vittala Temple",
    description:
      "Famous for its stone chariot and musical pillars, this temple is a masterpiece of Vijayanagara architecture and craftsmanship.",
    image: "https://i.pinimg.com/736x/ff/2d/6a/ff2d6ab7c9008f309c8b64262eef4a13.jpg?height=400&width=600",
    timings: "8:30 AM - 5:30 PM",
    entryFee: "₹40 for Indians, ₹500 for Foreigners",
    location: "Vittala Temple Road, Hampi",
    tags: ["Temple", "Architecture", "Stone Chariot"],
  },
  {
    id: 3,
    name: "Hampi Bazaar",
    description:
      "A historic market street lined with pavilions where traders once sold jewels, silk, and spices. Now it's a vibrant area with shops and cafes.",
    image: "https://i.pinimg.com/736x/13/54/e0/1354e034be41e403a95124df20c1d88c.jpg?height=400&width=600",
    timings: "Open all day",
    entryFee: "Free",
    location: "Hampi Bazaar Road, Hampi",
    tags: ["Market", "Heritage", "Shopping"],
  },
  {
    id: 4,
    name: "Elephant Stables",
    description:
      "A magnificent structure that once housed the royal elephants of the Vijayanagara Empire, featuring Indo-Islamic architectural elements.",
    image: "https://i.pinimg.com/736x/ec/43/90/ec4390908e794fb3a0c81f72c8b9d4ce.jpg?height=400&width=600",
    timings: "8:30 AM - 5:30 PM",
    entryFee: "Included in Hampi Group of Monuments ticket",
    location: "Royal Enclosure, Hampi",
    tags: ["Architecture", "Heritage", "Royal"],
  },
  {
    id: 5,
    name: "Lotus Mahal",
    description:
      "A beautiful pavilion with a unique blend of Hindu and Islamic architectural styles, featuring lotus-like arches and intricate carvings.",
    image: "https://i.pinimg.com/736x/af/35/10/af3510d77ad69d2153627d442ca0b2f1.jpg?height=400&width=600",
    timings: "8:30 AM - 5:30 PM",
    entryFee: "Included in Hampi Group of Monuments ticket",
    location: "Zenana Enclosure, Hampi",
    tags: ["Architecture", "Heritage", "Indo-Islamic"],
  },
]

export default function HampiPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Link
          href="/explore"
          className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-foreground mb-4"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Explore
        </Link>
        <h1 className="text-4xl font-bold tracking-tight mb-4">Explore Hampi</h1>
        <p className="text-lg text-muted-foreground max-w-3xl">
          Discover the ancient ruins of Hampi, a UNESCO World Heritage Site with stunning temples, monuments, and
          boulder-strewn landscapes.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Best Time to Visit</CardTitle>
          </CardHeader>
          <CardContent>
            <p>October to March</p>
            <p className="text-sm text-muted-foreground mt-1">
              Pleasant weather with temperatures between 20°C to 30°C
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Famous For</CardTitle>
          </CardHeader>
          <CardContent>
            <p>Ancient ruins, Stone chariot, Boulder landscapes, Tungabhadra river</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Duration</CardTitle>
          </CardHeader>
          <CardContent>
            <p>2-3 days recommended</p>
            <p className="text-sm text-muted-foreground mt-1">To explore major monuments and enjoy the landscape</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="attractions" className="w-full mb-16">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="attractions">Attractions</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
          <TabsTrigger value="tips">Travel Tips</TabsTrigger>
        </TabsList>
        <TabsContent value="attractions" className="p-4">
          <div className="grid grid-cols-1 gap-8">
            {attractions.map((attraction) => (
              <Card key={attraction.id} className="overflow-hidden">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="md:col-span-1">
                    <img
                      src={attraction.image || "/placeholder.svg"}
                      alt={attraction.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="md:col-span-2 p-6">
                    <div className="flex justify-between items-start">
                      <h3 className="text-xl font-bold">{attraction.name}</h3>
                      <Button variant="ghost" size="icon">
                        <Bookmark className="h-5 w-5" />
                        <span className="sr-only">Bookmark</span>
                      </Button>
                    </div>
                    <p className="text-muted-foreground mt-2 mb-4">{attraction.description}</p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div className="flex items-start gap-2">
                        <Clock className="h-5 w-5 text-amber-500 mt-0.5" />
                        <div>
                          <p className="font-medium">Timings</p>
                          <p className="text-sm text-muted-foreground">{attraction.timings}</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-2">
                        <Info className="h-5 w-5 text-amber-500 mt-0.5" />
                        <div>
                          <p className="font-medium">Entry Fee</p>
                          <p className="text-sm text-muted-foreground">{attraction.entryFee}</p>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-start gap-2 mb-4">
                      <MapPin className="h-5 w-5 text-amber-500 mt-0.5" />
                      <div>
                        <p className="font-medium">Location</p>
                        <p className="text-sm text-muted-foreground">{attraction.location}</p>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {attraction.tags.map((tag, index) => (
                        <span
                          key={index}
                          className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100 text-xs px-2 py-1 rounded-full"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="history" className="p-4">
          <Card>
            <CardHeader>
              <CardTitle>History of Hampi</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>
                Hampi was the capital of the Vijayanagara Empire, one of the greatest Hindu empires in India's history.
                The city's origins date back to the mid-14th century, and it flourished until its fall in 1565.
              </p>
              <p>
                <strong>Foundation:</strong> Hampi was founded by two local chieftains, Harihara and Bukka, in 1336 CE.
                With the guidance of the sage Vidyaranya, they established the Vijayanagara Empire with Hampi as its
                capital.
              </p>
              <p>
                <strong>Golden Age:</strong> Under the rule of Krishnadevaraya (1509-1529), Hampi reached its zenith.
                The empire expanded, and the city became a center of art, culture, trade, and learning. Foreign
                travelers described it as one of the most beautiful and prosperous cities in the world.
              </p>
              <p>
                <strong>Architecture and Culture:</strong> The rulers were great patrons of art and architecture,
                resulting in the construction of numerous temples, palaces, and public structures. The city's design
                reflected a blend of various architectural styles, including Dravidian, Indo-Islamic, and Deccan.
              </p>
              <p>
                <strong>Decline and Fall:</strong> In 1565, a coalition of Deccan sultanates defeated the Vijayanagara
                army at the Battle of Talikota. The capital was subsequently sacked and abandoned, marking the end of
                the empire's golden era.
              </p>
              <p>
                <strong>Rediscovery:</strong> Hampi remained forgotten for centuries until British colonial officials
                and archaeologists began to document and study the ruins in the 19th century. In 1986, UNESCO recognized
                Hampi as a World Heritage Site.
              </p>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="tips" className="p-4">
          <Card>
            <CardHeader>
              <CardTitle>Travel Tips for Hampi</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-4">
                <li className="flex items-start gap-2">
                  <div className="bg-amber-100 dark:bg-amber-900 rounded-full p-1 mt-0.5">
                    <span className="text-amber-800 dark:text-amber-100 text-xs font-bold">1</span>
                  </div>
                  <div>
                    <p className="font-medium">Rent a bicycle or scooter</p>
                    <p className="text-sm text-muted-foreground">
                      The monuments are spread across a large area, and having your own transportation makes exploration
                      easier.
                    </p>
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <div className="bg-amber-100 dark:bg-amber-900 rounded-full p-1 mt-0.5">
                    <span className="text-amber-800 dark:text-amber-100 text-xs font-bold">2</span>
                  </div>
                  <div>
                    <p className="font-medium">Carry sufficient water and wear comfortable footwear</p>
                    <p className="text-sm text-muted-foreground">
                      Exploring Hampi involves a lot of walking on rocky terrain under the sun.
                    </p>
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <div className="bg-amber-100 dark:bg-amber-900 rounded-full p-1 mt-0.5">
                    <span className="text-amber-800 dark:text-amber-100 text-xs font-bold">3</span>
                  </div>
                  <div>
                    <p className="font-medium">Watch the sunrise or sunset from Matanga Hill</p>
                    <p className="text-sm text-muted-foreground">
                      It offers a panoramic view of the entire Hampi landscape and is particularly beautiful during
                      golden hours.
                    </p>
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <div className="bg-amber-100 dark:bg-amber-900 rounded-full p-1 mt-0.5">
                    <span className="text-amber-800 dark:text-amber-100 text-xs font-bold">4</span>
                  </div>
                  <div>
                    <p className="font-medium">Take a coracle ride on the Tungabhadra River</p>
                    <p className="text-sm text-muted-foreground">
                      These traditional round boats offer a unique perspective of the ruins from the water.
                    </p>
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <div className="bg-amber-100 dark:bg-amber-900 rounded-full p-1 mt-0.5">
                    <span className="text-amber-800 dark:text-amber-100 text-xs font-bold">5</span>
                  </div>
                  <div>
                    <p className="font-medium">Stay on both sides of the river</p>
                    <p className="text-sm text-muted-foreground">
                      The Hampi Bazaar area has the main temples, while the Hippie Island (Virupapur Gaddi) offers a
                      more relaxed atmosphere.
                    </p>
                  </div>
                </li>
              </ul>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
